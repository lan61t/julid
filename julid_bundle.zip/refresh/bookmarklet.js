(async () => {
  if (!/basketball\.fantasysports\.yahoo\.com$/.test(location.host)) { alert('Open your Yahoo Fantasy Basketball league page first (signed in), then tap this bookmark again.'); return; }
  const box = document.createElement('div');
  box.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483647;background:#fff;color:#111;padding:16px;font:15px system-ui,sans-serif;overflow:auto';
  box.innerHTML = '<b>Reading your league from Yahoo… (about 40 seconds)</b>';
  document.body.appendChild(box);
  const L = '/nba/17676/';
  const get = async u => new DOMParser().parseFromString(await (await fetch(u, {credentials: 'include'})).text(), 'text/html');
  const clean = s => s.replace(/\s+/g, ' ').trim();
  const strip = (t, n) => clean(t.replace(n, '').replace(/New Player Note|No new player Notes|Player Note/g, ''));
  const out = {ts: new Date().toISOString(), teams: {}, fa: [], matchup: null, errors: []};
  try {
    const home = await get(L), ids = {};
    [...home.querySelectorAll('a')].forEach(a => { const m = a.href.match(/\/nba\/17676\/(\d+)$/); if (m && !(m[1] in ids)) ids[m[1]] = clean(a.innerText); });
    for (const id of Object.keys(ids)) {
      const d = await get(L + id);
      const name = (d.title.split(' - ')[1] || '').split(' |')[0] || ids[id];
      out.teams[id] = {name, players: [...d.querySelectorAll('tr')].filter(r => r.querySelector('a[href*="/nba/players/"]')).map(r => {
        const a = r.querySelector('a[href*="/nba/players/"]'), cells = [...r.children].map(c => clean(c.innerText));
        const nc = r.querySelector('.ysf-player-name') || a.parentElement.parentElement;
        return {pid: a.href.split('/').pop(), name: a.innerText.trim(), slot: cells[0], info: strip(nc.innerText, a.innerText.trim())};
      })};
    }
  } catch (e) { out.errors.push('teams: ' + e); }
  try {
    for (let c = 0; c < 200; c += 25) {
      const d = await get(L + 'players?status=A&pos=P&cut_type=33&stat1=S_PSR&myteam=0&sort=OR&sdir=1&count=' + c);
      [...d.querySelectorAll('tr')].filter(r => r.querySelector('a[href*="/nba/players/"]')).forEach(r => {
        const a = r.querySelector('a[href*="/nba/players/"]'), cells = [...r.children].map(x => clean(x.innerText));
        const nc = r.querySelector('.ysf-player-name') || a.parentElement.parentElement;
        out.fa.push({pid: a.href.split('/').pop(), name: a.innerText.trim(), info: strip(nc.innerText, a.innerText.trim()), own: cells.find(x => /^\d+%$/.test(x)) || ''});
      });
    }
  } catch (e) { out.errors.push('fa: ' + e); }
  try {
    const d = await get(L + 'matchup?mid1=9'), txt = d.body.innerText, wk = txt.match(/Week\s+(\d+)/), stats = {};
    [...d.querySelectorAll('table')].forEach(t => [...t.querySelectorAll('tr')].forEach(r => {
      const cells = [...r.children].map(c => clean(c.innerText));
      if (cells.length >= 11 && /\//.test(cells[1] || '') && cells[0] && !/^Player|^Team$/.test(cells[0])) stats[cells[0]] = cells.slice(1, 12);
    }));
    out.matchup = {week: wk ? +wk[1] : null, stats};
  } catch (e) { out.errors.push('matchup: ' + e); }
  const n = Object.keys(out.teams).length;
  box.innerHTML = '<p><b>' + (out.errors.length ? 'Problem: ' + out.errors.join('; ') : 'Done: ' + n + ' teams, ' + out.fa.length + ' free agents.') + '</b></p>' +
    '<p>1. Tap <b>Copy</b>. 2. Tap <b>Open GitHub editor</b>, select everything in the editor, paste, then tap <b>Commit changes</b>. The page updates about 2 minutes later.</p>' +
    '<textarea id="jd_t" readonly style="width:100%;height:25vh"></textarea>' +
    '<p><button id="jd_c" style="padding:10px 16px;font-size:16px">Copy</button> <a href="https://github.com/lan61t/julid/edit/main/yahoo.json" target="_blank" style="padding:10px 16px;font-size:16px">Open GitHub editor</a> <button id="jd_x" style="padding:10px 16px;font-size:16px">Close</button></p>';
  const ta = box.querySelector('#jd_t');
  ta.value = JSON.stringify(out);
  box.querySelector('#jd_c').onclick = async e => { ta.select(); try { await navigator.clipboard.writeText(ta.value); } catch (x) { document.execCommand('copy'); } e.target.textContent = 'Copied'; };
  box.querySelector('#jd_x').onclick = () => box.remove();
})();
