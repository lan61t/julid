"""Per-game Value in THIS league's 13 categories (same scale as the draft pool: z over the draftable 168, % cats as volume-weighted
impact, TO/PF sign-flipped), plus an efficiency-neutral version used to separate real production from shooting luck.

value_frame(df, Q)      df has box-score columns MIN FGM FGA FG3M FG3A FTM FTA OREB DREB AST TOV STL BLK PF PTS -> 13 z columns + 'value'
neutral_value(df, Q, rates)  same, but made shots replaced by (shrunk prior rate x attempts); 'luck' = value - neutral value
Value = sum of z weighted by the G-score reliability ratios (gh_core.RATIO), the weighting the draft playbook used.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402

CATS = G.CATS13
COUNT_COL = {"pts": "PTS", "stl": "STL", "blk": "BLK", "oreb": "OREB", "dreb": "DREB", "3pm": "FG3M", "ftm": "FTM", "to": "TOV",
             "pf": "PF", "ast": "AST"}
PCT_COL = {"fg_pct": ("FGM", "FGA"), "3p_pct": ("FG3M", "FG3A"), "ft_pct": ("FTM", "FTA")}
PSEUDO = {"fg_pct": 150.0, "3p_pct": 200.0, "ft_pct": 100.0}      # pseudo-attempts when shrinking a prior rate to the league rate


def value_frame(df, Q):
    z = pd.DataFrame(index=df.index)
    for c, col in COUNT_COL.items():
        z[c] = (df[col] - Q["mean"][c]) / Q["sd"][c]
    z[["to", "pf"]] *= -1
    for c, (a, b) in PCT_COL.items():
        imp = df[a] - Q["comp"][c] * df[b]
        z[c] = (imp - Q["imp_mean"][c]) / Q["imp_sd"][c]
    z = z[CATS]
    z["value"] = (z[CATS] * G.RATIO).sum(axis=1)
    return z


def shrunk_rates(prior_tot, Q):
    """prior_tot: DataFrame indexed like the players with season TOTAL columns FGM FGA FG3M FG3A FTM FTA -> shrunk shooting rates."""
    out = pd.DataFrame(index=prior_tot.index)
    for c, (a, b) in PCT_COL.items():
        out[c] = (prior_tot[a].fillna(0) + PSEUDO[c] * Q["comp"][c]) / (prior_tot[b].fillna(0) + PSEUDO[c])
    return out


def neutral_frame(df, rates, Q):
    """Box score with made shots replaced by rate x attempts (rates aligned to df's index)."""
    n = df.copy()
    n["FGM"] = np.maximum(rates["fg_pct"] * df["FGA"], 0)
    n["FG3M"] = np.minimum(rates["3p_pct"] * df["FG3A"], n["FGM"])
    n["FTM"] = rates["ft_pct"] * df["FTA"]
    n["PTS"] = 2 * n["FGM"] + n["FG3M"] + n["FTM"]
    return n


def neutral_value(df, rates, Q):
    zn = value_frame(neutral_frame(df, rates, Q), Q)
    return zn["value"]
