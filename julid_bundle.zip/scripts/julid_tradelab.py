"""Trade lab for the Yahoo Julid league (12 teams, 9 categories, 10 starters a day, no games cap): same Lab as the ESPN apps
(inseason_tradelab.Lab) with Julid's matchup engine plugged in. The page scores trades in the browser with a copy of this engine
(tradelab_engine.js, 'daily' mode), so the static site needs no server."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import julid_engine as J  # noqa: E402
import julid_fa as JF  # noqa: E402
import julid_trade as JT  # noqa: E402
from inseason_tradelab import Lab  # noqa: E402


class JulidEng:
    mode = "daily"
    CATS, LABEL, COMP, CI, LOWER = J.CATS, J.LABEL, J.COMP, J.CI, J.LOWER_BETTER
    win_need = J.WIN_NEED
    cat_values = staticmethod(J.cat_values)
    evaluate = staticmethod(J.evaluate)
    tv = staticmethod(JT._tv)
    power = staticmethod(JT._power)
    eff = staticmethod(JT._eff)
    bal = J.BAL9

    @staticmethod
    def cat_weights(z):
        return FA._cat_weights(z)[0]

    @staticmethod
    def wid(w):
        return w.w

    @staticmethod
    def player_val(p):
        return None                                  # a day's value depends on that day's usage: the page computes it from r

    @staticmethod
    def week_info(w):
        return {"mp": w.w, "n": w.n, "cap": 10 ** 9, "sun": None}

    @staticmethod
    def consts():
        rnd = lambda a, k: [round(float(x), k) for x in a]
        su = []
        for c in J.CATS:
            if c in J.PCT:
                a, b = J.PCT[c]
                su.append({"t": "p", "m": J.CI[a], "a": J.CI[b], "c": float(J.COMPOSITE[c]), "s": float(J.IMP_SD[c])})
            else:
                su.append({"t": "c", "i": J.CI[c], "s": float(J.SD[c]), "g": -1 if c in J.LOWER_BETTER else 1})
        ok = {k: sorted(v) for k, v in J.SLOT_OK.items()}
        ok["UTIL"] = ["PG", "SG", "SF", "PF", "C"]
        return {"sun_cap": 0, "has_cap": False, "buffer": 0.0, "abs_k": rnd(J.ABS_K9, 4), "kappa": 0.0,
                "slots": list(J.SLOTS), "slot_ok": ok, "tau": rnd(J.TAU9, 5), "g_avg": J.G_AVG, "su": su,
                "sd": [float(J.IMP_SD[c] if c in J.PCT else J.SD[c]) for c in J.CATS],
                "comp_q": {c: float(J.COMPOSITE[c]) for c in J.PCT}, "pct": {c: list(v) for c, v in J.PCT.items()}}


def build(teams, teams_pl, week, today, my_id, power_rows, fa_pl):
    """teams: {id: {name}}, teams_pl: {id: [players]}, power_rows: league power list (category strength per team)."""
    JF.configure()
    wks = [J.Week(w, real_today=today) for w in range(week, min(19, week + JT.N_WEEKS - 1) + 1)]
    z_by = {r["id"]: JF.team_z(r) for r in power_rows}
    meta = {t: {"name": teams[t]["name"], "owner": ""} for t in teams_pl}
    return Lab(JulidEng(), meta, teams_pl, wks, z_by, my_id, fa_pl, today)
