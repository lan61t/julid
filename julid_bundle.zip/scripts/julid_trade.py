"""Trade finder for the Yahoo Julid league (12 teams, 9 categories): the 1-for-1, 2-for-1 and 1-for-2 trades that raise MY power and do not
lower THEIRS. Same two stages as inseason_trade.py (cheap screen on depth-weighted team value, exact check with the matchup engine over the
next 4 weeks of schedule), judged with the Yahoo rules: 10 starters a day with position slots, no games cap, 13-player rosters.
After a trade a short roster takes the best healthy free agent and a long one drops its weakest player.
Limits: the same model that rated the rosters judges the trade; a trade is a suggestion to negotiate, not a promise the other manager agrees.
"""
import sys
from datetime import date
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402
import inseason_trade as ITR  # noqa: E402
import julid_engine as J  # noqa: E402
import julid_fa as JF  # noqa: E402

N_WEEKS = 4
SCREEN_PER_PARTNER = 6
MAX_ROWS = 14
MIN_THEM, MIN_ME = -0.002, 0.004


def _tv(players, wks):
    ts, vs = [], []
    for wk in wks:
        a, v = J.aggregate(J.team_pack(players, wk, J.BAL9))
        ts.append(a)
        vs.append(v)
    return np.mean(ts, axis=0), np.mean(vs, axis=0)


def _power(a, tot, var):
    return float(np.mean([J.evaluate(tot[a], var[a], tot[b], var[b])[1] for b in tot if b != a]))


def _eff(p, wts, today):
    u = p["u"] - FA.CFG["u0"]
    f, _ = FA.avail_frac(p, today)
    v = float((u * wts).sum())
    return v * f if v >= 0 else v


def find_trades(teams, teams_pl, week, today, my_id, power_rows, fa_pl):
    """teams: {id: {name, ...}}, teams_pl: {id: [players]}, power_rows: the league power list (for each team's category z)."""
    JF.configure()
    wks = [J.Week(w, real_today=today) for w in range(week, min(19, week + N_WEEKS - 1) + 1)]
    z_by = {r["id"]: JF.team_z(r) for r in power_rows}
    ids = list(teams_pl)
    base = {t: _tv(teams_pl[t], wks) for t in ids}
    tot = {t: base[t][0] for t in ids}
    var = {t: base[t][1] for t in ids}
    pw0 = {t: _power(t, tot, var) for t in ids}
    vals0 = {t: J.cat_values(tot[t]) for t in ids}
    cm = {c: np.mean([vals0[t][c] for t in ids]) for c in J.CATS}
    cs = {c: (np.std([vals0[t][c] for t in ids]) or 1.0) for c in J.CATS}

    def zcat(v):
        return {c: ((v[c] - cm[c]) / cs[c]) * (-1 if c in J.LOWER_BETTER else 1) for c in J.CATS}

    z0 = {t: zcat(vals0[t]) for t in ids}
    size = {t: len(teams_pl[t]) for t in ids}
    fill = sorted([f for f in fa_pl if str(f.get("inj") or "ACTIVE").upper() in ("ACTIVE", "DAY_TO_DAY")],
                  key=lambda f: -_eff(f, J.BAL9, today))
    out, screened = [], 0
    for pid in ids:
        if pid == my_id:
            continue
        wm, _ = FA._cat_weights(z_by[my_id])
        wp, _ = FA._cat_weights(z_by[pid])
        mine, theirs = teams_pl[my_id], teams_pl[pid]
        em = {p["name"]: _eff(p, wm, today) for p in mine}
        ep = {p["name"]: _eff(p, wp, today) for p in theirs}
        em_all = {**em, **{p["name"]: _eff(p, wm, today) for p in theirs}}
        ep_all = {**ep, **{p["name"]: _eff(p, wp, today) for p in mine}}
        b_me, b_th = FA.team_value([em[p["name"]] for p in mine]), FA.team_value([ep[p["name"]] for p in theirs])
        cands = []
        for ng in (1, 2):
            for nt in (1, 2):
                if ng == 2 and nt == 2:
                    continue
                for give in combinations(mine, ng):
                    for get in combinations(theirs, nt):
                        g_names, t_names = {p["name"] for p in give}, {p["name"] for p in get}
                        new_me = [p for p in mine if p["name"] not in g_names] + list(get)
                        new_th = [p for p in theirs if p["name"] not in t_names] + list(give)
                        v_me = sorted([em_all[p["name"]] for p in new_me], reverse=True)[:size[my_id]]
                        v_th = sorted([ep_all[p["name"]] for p in new_th], reverse=True)[:size[pid]]
                        d_me, d_th = FA.team_value(v_me) - b_me, FA.team_value(v_th) - b_th
                        sc = FA.S()
                        if d_me > 0.05 * sc and d_th > -0.15 * sc:
                            cands.append((d_me + 1.5 * min(d_th, 0.3 * sc), give, get, d_me, d_th))
        cands.sort(key=lambda x: -x[0])
        picked, seen = [], set()
        for _s, give, get, d_me, d_th in cands:
            key = (frozenset(p["name"] for p in give), frozenset(p["name"] for p in get))
            if key in seen:
                continue
            seen.add(key)
            picked.append((give, get))
            if len(picked) >= SCREEN_PER_PARTNER:
                break
        screened += len(cands)
        for give, get in picked:
            g_names, t_names = {p["name"] for p in give}, {p["name"] for p in get}
            new_me = [p for p in mine if p["name"] not in g_names] + list(get)
            new_th = [p for p in theirs if p["name"] not in t_names] + list(give)
            new_me, add_me = ITR._settle(new_me, size[my_id], fill, t_names, {p["name"]: em_all[p["name"]] for p in new_me})
            new_th, add_th = ITR._settle(new_th, size[pid], fill, g_names, {p["name"]: ep_all[p["name"]] for p in new_th})
            kept_me, kept_th = {q["name"] for q in new_me}, {q["name"] for q in new_th}
            drop_me = [p["name"] for p in mine if p["name"] not in g_names and p["name"] not in kept_me]
            drop_th = [p["name"] for p in theirs if p["name"] not in t_names and p["name"] not in kept_th]
            a1, v1 = _tv(new_me, wks)
            a2, v2 = _tv(new_th, wks)
            tot2, var2 = dict(tot), dict(var)
            tot2[my_id], var2[my_id], tot2[pid], var2[pid] = a1, v1, a2, v2
            pm, pt = _power(my_id, tot2, var2), _power(pid, tot2, var2)
            zm, zt = zcat(J.cat_values(a1)), zcat(J.cat_values(a2))
            cm_ch = [(J.LABEL[c], zm[c] - z0[my_id][c]) for c in J.CATS if abs(zm[c] - z0[my_id][c]) >= 0.2]
            ct_ch = [(J.LABEL[c], zt[c] - z0[pid][c]) for c in J.CATS if abs(zt[c] - z0[pid][c]) >= 0.2]
            out.append({"partner_id": pid, "partner": teams[pid]["name"], "owner": "", "give": [p["name"] for p in give],
                        "get": [p["name"] for p in get], "kind": f"{len(give)}-for-{len(get)}", "fill_me": add_me, "drop_me": drop_me,
                        "fill_them": add_th, "drop_them": drop_th, "me_from": pw0[my_id], "me_to": pm, "them_from": pw0[pid], "them_to": pt,
                        "d_me": pm - pw0[my_id], "d_them": pt - pw0[pid],
                        "me_cats": [{"cat": c, "dz": float(d)} for c, d in sorted(cm_ch, key=lambda x: -abs(x[1]))[:5]],
                        "them_cats": [{"cat": c, "dz": float(d)} for c, d in sorted(ct_ch, key=lambda x: -abs(x[1]))[:5]]})
    for r in out:
        r["verdict"] = ("WIN-WIN" if r["d_me"] >= MIN_ME and r["d_them"] >= 0.002 else "FAIR" if r["d_me"] >= MIN_ME and r["d_them"] >= MIN_THEM
                        else "ONE-SIDED" if r["d_me"] >= MIN_ME else "NO")
    good = [r for r in out if r["verdict"] != "NO"]
    rank = {"WIN-WIN": 0, "FAIR": 1, "ONE-SIDED": 2}
    good.sort(key=lambda r: (rank[r["verdict"]], -r["d_me"]))
    rows, per = [], {}
    for r in good:
        if per.get(r["partner_id"], 0) < 2:
            rows.append(r)
            per[r["partner_id"]] = per.get(r["partner_id"], 0) + 1
        if len(rows) >= MAX_ROWS:
            break
    return {"rows": rows, "screened": screened, "checked": len(out), "weeks": [w.w for w in wks], "my_power": pw0[my_id],
            "rule": {"min_me": MIN_ME, "min_them": MIN_THEM}}
