"""Daily box score in THIS league's scoring (13 cats) with a real-vs-fluke read on every line -- the Basketball Monster box-score idea
(their page is partly members-only, so this is built from NBA box scores, not scraped from them).

For each player line on a date:
  value / z per category   same scale as the draft pool (z over the draftable 168, G-score weights)
  luck                     value minus the value if his made shots had gone in at his own (shrunk) usual rates
  proj_next10              expected Value over his next 10 games from the walk-forward model fitted by research_daily_signal.py
                           (prior-season value, this game's neutral value, luck, minutes, minutes-vs-usual, last-10 form)
  verdict                  PICKUP / WATCH / FLUKE / IGNORE with the reasons in words
What the model learned (test season 2025-26, see data/research/daily_signal_model.json): shooting luck carries ~0 into the next 10
games; a minutes jump carries +0.053 Value per minute; the single-game line adds very little beyond the player's own track record.
Preseason games are flagged: rotations and minutes there are not comparable to the regular season.
"""
import json
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_value as IV  # noqa: E402
from inseason_live import LAST, Q, norm, SEASON_START  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = G.ROOT
CACHE = ROOT / "data" / "live"
CACHE.mkdir(parents=True, exist_ok=True)
MODEL = json.loads((ROOT / "data" / "research" / "daily_signal_model.json").read_text())
CAT_LABEL = {"pts": "PTS", "stl": "STL", "blk": "BLK", "oreb": "OREB", "dreb": "DREB", "fg_pct": "FG%", "3pm": "3PM", "3p_pct": "3P%",
             "ftm": "FTM", "ft_pct": "FT%", "to": "TO", "pf": "PF", "ast": "AST"}
TOT = ["FGM", "FGA", "FG3M", "FG3A", "FTM", "FTA"]

_prior = LAST.drop_duplicates("PLAYER_ID").copy()
_prior["k"] = _prior["PLAYER_NAME"].map(norm)                # ESPN and NBA player ids differ: players are matched by name
_prior = _prior.drop_duplicates("k").set_index("k")
_prior = _prior[_prior["GP"] >= 20]
_rates = IV.shrunk_rates(_prior[TOT].mul(_prior["GP"], axis=0), Q)
_prior_v = IV.value_frame(_prior, Q)["value"]


_POOL_G = None


def _pool_g():
    global _POOL_G
    if _POOL_G is None:
        p = pd.read_csv(ROOT / "data" / "pool_2026-27_v31.csv").drop_duplicates("PLAYER_NAME")
        _POOL_G = pd.Series(p["g_total"].to_numpy(), index=p["PLAYER_NAME"].map(norm))
        _POOL_G = _POOL_G[~_POOL_G.index.duplicated()]
    return _POOL_G


def _minutes(s):
    try:
        m, sec = str(s).split(":")
        return int(m) + int(sec) / 60
    except Exception:
        return 0.0


LINES = CACHE / "season_lines.csv"            # every regular-season player line seen so far (ESPN box scores), the in-season record
_LINE_COLS = ["GAME_DATE", "GAME_ID", "PLAYER_NAME", "TEAM_ABBREVIATION", "MIN", "FGM", "FGA", "FG3M", "FG3A", "FTM", "FTA", "OREB", "DREB",
              "AST", "TOV", "STL", "BLK", "PF", "PTS"]


def fetch_day(d):
    """Player lines + starter flags + game results for one date, from ESPN's public box scores (cached once a game is final)."""
    import espn_site as ES
    r = ES.box_lines(d)
    st = "Pre Season" if d < SEASON_START else "Regular Season"
    starters = {str(x["PLAYER_ID"]): (bool(x["STARTER"]), "") for x in r["lines"]}
    out = {"date": d.isoformat(), "season_type": st, "lines": r["lines"], "starters": starters, "games": r["games"],
           "all_final": r["all_final"]}
    if st == "Regular Season" and r["lines"]:
        store_lines(d, r["lines"], r["all_final"])
    return out


def store_lines(d, lines, final):
    """Append a finished day to season_lines.csv (once per date; a day that is still in progress is not stored)."""
    if not final:
        return
    have = pd.read_csv(LINES, usecols=["GAME_DATE"]) if LINES.exists() else pd.DataFrame(columns=["GAME_DATE"])
    if d.isoformat() in set(have["GAME_DATE"].astype(str)):
        return
    df = pd.DataFrame(lines).assign(GAME_DATE=d.isoformat())[_LINE_COLS]
    df.to_csv(LINES, mode="a", header=not LINES.exists(), index=False)


def season_logs(upto):
    """Regular-season lines before `upto` (empty in preseason), used for last-10 form and the in-season projection update."""
    if not LINES.exists() or upto <= SEASON_START:
        return pd.DataFrame()
    d = pd.read_csv(LINES)
    d = d[(d["GAME_DATE"] < upto.isoformat()) & (d["MIN"] >= 8)].copy()
    d["k"] = d["PLAYER_NAME"].map(norm)
    return d


def project(lines, logs):
    """Adds z, value, neutral value, luck, model projection of next-10 Value."""
    df = pd.DataFrame(lines)
    if df.empty:
        return df
    df["k"] = df["PLAYER_NAME"].map(norm)
    z = IV.value_frame(df, Q)
    for c in G.CATS13:
        df[f"z_{c}"] = z[c].to_numpy()
    df["V"] = z["value"].to_numpy()
    rates = pd.DataFrame({c: df["k"].map(_rates[c]).fillna(Q["comp"][c]) for c in IV.PCT_COL})
    df["N"] = IV.neutral_value(df, rates, Q).to_numpy()
    df["L"] = df["V"] - df["N"]
    df["prior_v"] = df["k"].map(_prior_v)
    df["prior_min"] = df["k"].map(_prior["MIN"])
    df["prior_src"] = np.where(df["prior_v"].notna(), "last season", "")
    miss = df["prior_v"].isna()                              # rookies / returners: fall back to the preseason projection (G-score)
    if miss.any():
        pj = _pool_g().reindex(df.loc[miss, "PLAYER_NAME"].map(norm))
        df.loc[miss, "prior_v"] = pj.to_numpy()
        df.loc[miss & df["prior_v"].notna(), "prior_src"] = "preseason projection"
    df["has_prior"] = df["prior_v"].notna()
    df["min"] = df["MIN"]
    df["dmin"] = (df["min"] - df["prior_min"]).fillna(0.0)   # unknown usual minutes -> no role-jump claim
    if len(logs):
        lv = IV.value_frame(logs, Q)["value"]
        lg = logs.assign(V=lv.to_numpy()).sort_values("GAME_DATE").groupby("k")["V"].apply(lambda x: x.tail(10).mean() if len(x) >= 5 else np.nan)
        df["r10"] = df["k"].map(lg)
    else:
        df["r10"] = np.nan
    df["r10_miss"] = df["r10"].isna().astype(float)
    df["r10"] = df["r10"].fillna(df["prior_v"])
    c = MODEL["coef"]
    ok = df["has_prior"]
    df["proj"] = np.nan
    df.loc[ok, "proj"] = (c["const"] + sum(c[k] * df.loc[ok, k] for k in MODEL["features"]))
    return df


def verdict(r, owned_by, own_pct, preseason, injured_mates):
    reasons, tag = [], "IGNORE"
    v, proj, dmin, mn = r["V"], r["proj"], r["dmin"], r["min"]
    if pd.isna(proj):
        return "NO PRIOR", ["no track record or projection for him: judge by minutes over several games"]
    if r.get("prior_src") == "preseason projection":
        reasons.append("no 2025-26 line: compared against his preseason projection instead")
    gap = v - proj
    if abs(r["L"]) >= 2.0:
        reasons.append(f"{'hot' if r['L'] > 0 else 'cold'} shooting {r['L']:+.1f} of his Value is luck (carries ~0 forward)")
    if dmin >= 6 and mn >= 20:
        reasons.append(f"{mn:.0f} min vs usual {r['prior_min']:.0f}: a real role jump (+0.05 Value per extra minute persists)")
        if injured_mates:
            reasons.append("teammate(s) out: " + ", ".join(injured_mates[:2]) + " (temporary until they return)")
    elif mn < 15:
        reasons.append(f"only {mn:.0f} min: too little role to trust")
    if gap >= 6 and dmin < 5:
        tag = "FLUKE"
        reasons.append(f"game Value {v:.1f} vs expected {proj:.1f} with no role change: mostly noise, does not change his outlook")
    elif proj >= 1.0 and not owned_by:
        tag = "PICKUP"
        reasons.append(f"model expects Value {proj:.1f} over the next 10 games (about a top-170 player)")
    elif proj >= 0 and dmin >= 6 and mn >= 20 and not owned_by:
        tag = "WATCH"
    elif proj >= 1.0 and owned_by:
        tag = "ROSTERED"
    if preseason and tag in ("PICKUP", "WATCH"):
        tag = "WATCH"
        reasons.append("preseason game: rotations and minutes are not reliable; confirm in the first regular-season games")
    return tag, reasons


def build_daily(d, espn_state=None, need_cats=None):
    """espn_state: dict from inseason_live.pull_espn (rostered/FA info), need_cats: list of cat keys where my matchup is weak."""
    raw = fetch_day(d)
    pre = raw.get("season_type") == "Pre Season"
    df = project(raw["lines"], season_logs(d))
    if df.empty:
        return {"date": d.isoformat(), "preseason": pre, "games": [], "players": [], "note": "No games on this date."}
    start = {int(k): v for k, v in raw["starters"].items()}
    owner, own_pct, inj = {}, {}, {}
    if espn_state:
        for t in espn_state["teams"].values():
            for p in t["roster"]:
                owner[norm(p["name"])] = t["name"]
                inj[norm(p["name"])] = p["inj"]
        for f in espn_state["fa"]:
            own_pct[norm(f["name"])] = f["own"]
            inj[norm(f["name"])] = f["inj"]
    out_by_team = {}
    for k, v in inj.items():
        pass
    df["rank"] = df["V"].rank(ascending=False, method="min").astype(int)
    df = df.sort_values("V", ascending=False)
    rows = []
    for r in df.itertuples(index=False):
        r = r._asdict() if hasattr(r, "_asdict") else dict(r)
        k = norm(r["PLAYER_NAME"])
        stt = start.get(int(r["PLAYER_ID"]), (False, ""))
        zc = {c: round(float(r[f"z_{c}"]), 2) for c in G.CATS13}
        tag, reasons = verdict(r, owner.get(k), own_pct.get(k), pre, [])
        if tag == "FLUKE" and owner.get(k):
            tag = "NOISE"                                   # already on a roster: the point is the big night changes nothing
        best = [c for c in sorted(zc, key=lambda c: -zc[c])[:4] if c not in ("pf", "to")]
        fits = [CAT_LABEL[c] for c in best if tag in ("PICKUP", "WATCH") and need_cats and c in need_cats and zc[c] > 0.5]
        m = raw["games"][r["GAME_ID"]]
        rows.append({"rank": int(r["rank"]), "name": r["PLAYER_NAME"], "team": r["TEAM_ABBREVIATION"], "game": m["matchup"], "start": bool(stt[0]),
                     "pos": stt[1], "min": round(float(r["min"]), 1), "pts": int(r["PTS"]), "fg3": int(r["FG3M"]), "reb": int(r["OREB"] + r["DREB"]),
                     "ast": int(r["AST"]), "stl": int(r["STL"]), "blk": int(r["BLK"]), "fgm": int(r["FGM"]), "fga": int(r["FGA"]), "ftm": int(r["FTM"]),
                     "fta": int(r["FTA"]), "to": int(r["TOV"]), "pf": int(r["PF"]), "pm": int(r["PLUS_MINUS"]), "value": round(float(r["V"]), 2),
                     "neutral": round(float(r["N"]), 2), "luck": round(float(r["L"]), 2),
                     "proj": None if pd.isna(r["proj"]) else round(float(r["proj"]), 2), "dmin": None if pd.isna(r["dmin"]) else round(float(r["dmin"]), 1),
                     "z": zc, "verdict": tag, "reasons": reasons, "owner": owner.get(k), "own_pct": own_pct.get(k), "inj": inj.get(k, ""),
                     "fits": fits})
    games = [{"matchup": g["matchup"], "score": " - ".join(f"{t} {p}" for t, p in g["pts"].items())} for g in raw["games"].values()]
    return {"date": d.isoformat(), "preseason": pre, "games": games, "players": rows,
            "note": ("Preseason: rotations/minutes unreliable; verdicts are capped at WATCH. " if pre else "") +
                    "Model: walk-forward, test R2 0.55 for next-10-game Value (prior only: 0.44).",
            "model": {"luck_persistence": MODEL["luck_persistence"], "min_jump_per_minute": MODEL["coef"]["dmin"], "report": MODEL["report"]}}


if __name__ == "__main__":
    d = date.fromisoformat(sys.argv[1]) if len(sys.argv) > 1 else date(2026, 10, 13)
    res = build_daily(d)
    print(res["date"], "preseason" if res["preseason"] else "regular", len(res["players"]), "players;", res["note"])
    for p in res["players"][:14]:
        print(f"#{p['rank']:3d} {p['name']:24s} {p['team']} {'S' if p['start'] else ' '} {p['min']:5.1f}m {p['pts']:2d}p {p['reb']:2d}r {p['ast']:2d}a "
              f"V={p['value']:6.2f} luck={p['luck']:+5.2f} proj10={p['proj']} dmin={p['dmin']} -> {p['verdict']}  {'; '.join(p['reasons'])[:110]}")
    from collections import Counter
    print(Counter(p["verdict"] for p in res["players"]))
