"""Daily box score in THIS league's scoring (13 cats) with a real-vs-fluke read on every line -- the Basketball Monster box-score idea
(their page is partly members-only, so this is built from NBA box scores, not scraped from them).

For each player line on a date:
  value / z per category   same scale as the draft pool (z over the draftable 168, G-score weights)
  luck                     value minus the value if his made shots had gone in at his own (shrunk) usual rates
  proj_next10              expected Value over his next 10 games from the walk-forward model fitted by research_daily_signal.py
                           (prior-season value, this game's neutral value, luck, minutes, minutes-vs-usual, last-10 form)
  verdict                  PICKUP / WATCH / FLUKE / IGNORE with the reasons in words
What the model learned (test season 2025-26, see data/research/daily_signal_model.json): shooting luck carries ~0 into the next 10
games; a minutes jump carries +0.053 Value per minute; the single-game line adds very little beyond the player's own track record.
Preseason games are flagged: rotations and minutes there are not comparable to the regular season.
"""
import json
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_value as IV  # noqa: E402
from inseason_live import LAST, Q, norm, SEASON_START  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = G.ROOT
CACHE = ROOT / "data" / "live"
CACHE.mkdir(parents=True, exist_ok=True)
MODEL = json.loads((ROOT / "data" / "research" / "daily_signal_model.json").read_text())
CAT_LABEL = {"pts": "PTS", "stl": "STL", "blk": "BLK", "oreb": "OREB", "dreb": "DREB", "fg_pct": "FG%", "3pm": "3PM", "3p_pct": "3P%",
             "ftm": "FTM", "ft_pct": "FT%", "to": "TO", "pf": "PF", "ast": "AST"}
TOT = ["FGM", "FGA", "FG3M", "FG3A", "FTM", "FTA"]

_prior = LAST.drop_duplicates("PLAYER_ID").copy()
_prior["k"] = _prior["PLAYER_NAME"].map(norm)                # ESPN and NBA player ids differ: players are matched by name
_prior = _prior.drop_duplicates("k").set_index("k")
_prior = _prior[_prior["GP"] >= 20]
_rates = IV.shrunk_rates(_prior[TOT].mul(_prior["GP"], axis=0), Q)
_prior_v = IV.value_frame(_prior, Q)["value"]


_POOL_G = None


def _pool_g():
    global _POOL_G
    if _POOL_G is None:
        p = pd.read_csv(ROOT / "data" / "pool_2026-27_v31.csv").drop_duplicates("PLAYER_NAME")
        _POOL_G = pd.Series(p["g_total"].to_numpy(), index=p["PLAYER_NAME"].map(norm))
        _POOL_G = _POOL_G[~_POOL_G.index.duplicated()]
    return _POOL_G


def _minutes(s):
    try:
        m, sec = str(s).split(":")
        return int(m) + int(sec) / 60
    except Exception:
        return 0.0


LINES = CACHE / "season_lines.csv"            # every regular-season player line seen so far (ESPN box scores), the in-season record
_LINE_COLS = ["GAME_DATE", "GAME_ID", "PLAYER_NAME", "TEAM_ABBREVIATION", "MIN", "FGM", "FGA", "FG3M", "FG3A", "FTM", "FTA", "OREB", "DREB",
              "AST", "TOV", "STL", "BLK", "PF", "PTS"]


def fetch_day(d):
    """Player lines + starter flags + game results for one date, from ESPN's public box scores (cached once a game is final)."""
    import espn_site as ES
    r = ES.box_lines(d)
    st = "Pre Season" if d < SEASON_START else "Regular Season"
    starters = {str(x["PLAYER_ID"]): (bool(x["STARTER"]), "") for x in r["lines"]}
    out = {"date": d.isoformat(), "season_type": st, "lines": r["lines"], "starters": starters, "games": r["games"],
           "all_final": r["all_final"], "dnp": r.get("dnp", [])}
    if st == "Regular Season" and r["lines"]:
        store_lines(d, r["lines"], r["all_final"])
    return out


def store_lines(d, lines, final):
    """Append a finished day to season_lines.csv (once per date; a day that is still in progress is not stored)."""
    if not final:
        return
    have = pd.read_csv(LINES, usecols=["GAME_DATE"]) if LINES.exists() else pd.DataFrame(columns=["GAME_DATE"])
    if d.isoformat() in set(have["GAME_DATE"].astype(str)):
        return
    df = pd.DataFrame(lines).assign(GAME_DATE=d.isoformat())[_LINE_COLS]
    df.to_csv(LINES, mode="a", header=not LINES.exists(), index=False)


def season_logs(upto):
    """Regular-season lines before `upto` (empty in preseason), used for last-10 form and the in-season projection update."""
    if not LINES.exists() or upto <= SEASON_START:
        return pd.DataFrame()
    d = pd.read_csv(LINES)
    d = d[(d["GAME_DATE"] < upto.isoformat()) & (d["MIN"] >= 8)].copy()
    d["k"] = d["PLAYER_NAME"].map(norm)
    return d


CAT_LABEL9 = {"fg_pct": "FG%", "ft_pct": "FT%", "3pm": "3PM", "pts": "PTS", "reb": "REB", "ast": "AST", "stl": "STL", "blk": "BLK", "to": "TO"}
_CFG = {}


def get_cfg(cats=13):
    """Everything that differs between the ESPN league (13 cats) and the Yahoo league (9 cats): value function, weights, labels, model.
    `scale` = typical size of a 9-cat Value relative to a 13-cat one (julid_value.scale_vs_13): every Value threshold is multiplied by it."""
    if cats in _CFG:
        return _CFG[cats]
    if cats == 13:
        c = {"n": 13, "cats": list(G.CATS13), "label": CAT_LABEL, "w": [float(x) for x in G.RATIO], "scale": 1.0, "model": MODEL,
             "vf": lambda df: IV.value_frame(df, Q), "nf": lambda df, r: IV.neutral_value(df, r, Q), "prior_v": _prior_v}
    else:
        import julid_value as JV
        mp = ROOT / "data" / "research" / "daily_signal_model_9cat.json"
        c = {"n": 9, "cats": list(JV.CATS9), "label": CAT_LABEL9, "w": [float(x) for x in JV.BAL9], "scale": float(JV.scale_vs_13()),
             "model": json.loads(mp.read_text()), "vf": lambda df: JV.value_frame9(df, Q), "nf": lambda df, r: JV.neutral_value9(df, r, Q),
             "prior_v": JV.value_frame9(_prior, Q)["value"]}
    _CFG[cats] = c
    return c


def usage(df):
    """Usage% of each line from the game's own team totals (the standard formula; no extra data needed)."""
    pos = df["FGA"] + 0.44 * df["FTA"] + df["TOV"]
    g = df.assign(_p=pos).groupby(["GAME_ID", "TEAM_ABBREVIATION"])
    tm, tp = g["MIN"].transform("sum"), g["_p"].transform("sum")
    return 100 * pos * (tm / 5) / (df["MIN"].clip(lower=1) * tp.clip(lower=1))


def _usual_usage():
    """Each player's usage over last season (minutes-weighted, 20+ games), from the cached 2025-26 game logs."""
    cache = ROOT / "data" / "research" / "usual_usage.json"        # precomputed so the cloud bundle does not need the 2025-26 game logs
    if cache.exists():
        return json.loads(cache.read_text())
    try:
        g = pd.read_csv(ROOT / "data" / "raw" / "long" / "gamelogs_2025-26.csv")
        g["TEAM_ABBREVIATION"] = g["TEAM_ID"]
        g["usg"] = usage(g)
        g = g[g["MIN"] >= 8].copy()
        g["k"] = g["PLAYER_NAME"].map(norm)
        w = g.groupby("k").apply(lambda x: np.average(x["usg"], weights=x["MIN"]) if len(x) >= 20 else np.nan, include_groups=False).dropna()
        cache.write_text(json.dumps({k: round(float(v), 2) for k, v in w.items()}))
        return w.to_dict()
    except Exception:
        return {}


_usual_usg = _usual_usage()


def project(lines, logs, cfg=None):
    """Adds z, value, neutral value, luck, model projection of next-10 Value (in cfg's categories: 13 by default)."""
    cfg = cfg or get_cfg(13)
    df = pd.DataFrame(lines)
    if df.empty:
        return df
    df["k"] = df["PLAYER_NAME"].map(norm)
    z = cfg["vf"](df)
    for c in cfg["cats"]:
        df[f"z_{c}"] = z[c].to_numpy()
    df["V"] = z["value"].to_numpy()
    rates = pd.DataFrame({c: df["k"].map(_rates[c]).fillna(Q["comp"][c]) for c in IV.PCT_COL})
    df["N"] = cfg["nf"](df, rates).to_numpy()
    df["L"] = df["V"] - df["N"]
    df["prior_v"] = df["k"].map(cfg["prior_v"])
    df["prior_min"] = df["k"].map(_prior["MIN"])
    df["prior_src"] = np.where(df["prior_v"].notna(), "last season", "")
    miss = df["prior_v"].isna()                              # rookies / returners: fall back to the preseason projection (G-score)
    if miss.any():
        pj = _pool_g().reindex(df.loc[miss, "PLAYER_NAME"].map(norm)) * cfg["scale"]
        df.loc[miss, "prior_v"] = pj.to_numpy()
        df.loc[miss & df["prior_v"].notna(), "prior_src"] = "preseason projection"
    df["has_prior"] = df["prior_v"].notna()
    df["min"] = df["MIN"]
    df["dmin"] = (df["min"] - df["prior_min"]).fillna(0.0)   # unknown usual minutes -> no role-jump claim
    df["usg"] = usage(df)
    if len(logs):
        lv = cfg["vf"](logs)["value"]
        lg = logs.assign(V=lv.to_numpy()).sort_values("GAME_DATE").groupby("k")["V"].apply(lambda x: x.tail(10).mean() if len(x) >= 5 else np.nan)
        df["r10"] = df["k"].map(lg)
    else:
        df["r10"] = np.nan
    df["r10_miss"] = df["r10"].isna().astype(float)
    df["r10"] = df["r10"].fillna(df["prior_v"])
    c = cfg["model"]["coef"]
    ok = df["has_prior"]
    df["proj"] = np.nan
    df.loc[ok, "proj"] = (c["const"] + sum(c[k] * df.loc[ok, k] for k in cfg["model"]["features"]))
    return df


def verdict(r, owned_by, own_pct, preseason, injured_mates, sc=1.0):
    reasons, tag = [], "IGNORE"
    v, proj, dmin, mn = r["V"], r["proj"], r["dmin"], r["min"]
    if pd.isna(proj):
        return "NO PRIOR", ["no track record or projection for him: judge by minutes over several games"]
    if r.get("prior_src") == "preseason projection":
        reasons.append("no 2025-26 line: compared against his preseason projection instead")
    gap = v - proj
    if abs(r["L"]) >= 2.0 * sc:
        reasons.append(f"{'hot' if r['L'] > 0 else 'cold'} shooting {r['L']:+.1f} of his Value is luck (carries ~0 forward)")
    if dmin >= 6 and mn >= 20:
        reasons.append(f"{mn:.0f} min vs usual {r['prior_min']:.0f}: a real role jump (+0.05 Value per extra minute persists)")
        if injured_mates:
            reasons.append("teammate(s) out: " + ", ".join(injured_mates[:3]) + " (temporary until they return)")
    elif injured_mates and mn >= 15:
        reasons.append("teammate(s) out: " + ", ".join(injured_mates[:3]) + ": part of this night is the opening, not the player")
    elif mn < 15:
        reasons.append(f"only {mn:.0f} min: too little role to trust")
    ud = r.get("dusg")
    if ud is not None and not pd.isna(ud) and abs(ud) >= 6 and mn >= 15:
        reasons.append(f"usage {r['usg']:.0f}% vs {r['usg'] - ud:.0f}% usual: " + (
            "he carried more of the offence than normal (tested: only about +0.3 Value over the next 10, a small signal)" if ud > 0 else "he was used much less than normal"))
    if r.get("blow"):
        reasons.append("blowout game: garbage-time minutes can inflate or hide a line")
    if r.get("foul_trouble"):
        reasons.append(f"{int(r['PF'])} fouls in {mn:.0f} min: foul trouble capped the night")
    if gap >= 6 * sc and dmin < 5:
        tag = "FLUKE"
        reasons.append(f"game Value {v:.1f} vs expected {proj:.1f} with no role change: mostly noise, does not change his outlook")
    elif proj >= 1.0 * sc and not owned_by:
        tag = "PICKUP"
        reasons.append(f"model expects Value {proj:.1f} over the next 10 games (about a top-170 player)")
    elif proj >= 0 and dmin >= 6 and mn >= 20 and not owned_by:
        tag = "WATCH"
    elif proj >= 1.0 * sc and owned_by:
        tag = "ROSTERED"
    if preseason and tag in ("PICKUP", "WATCH"):
        tag = "WATCH"
        reasons.append("preseason game: rotations and minutes are not reliable; confirm in the first regular-season games")
    return tag, reasons


def build_daily(d, espn_state=None, need_cats=None, cats=13, owners=None):
    """espn_state: dict from inseason_live.pull_espn (rostered/FA info), need_cats: list of cat keys where my matchup is weak.
    cats=9 gives the Yahoo league's version; there `owners` = {"owner": {name key: {"team", "side"}}, "pct": {name key: % owned}, "inj": {name key: tag}}
    comes from the Yahoo snapshots instead of ESPN."""
    cfg = get_cfg(cats)
    sc = cfg["scale"]
    raw = fetch_day(d)
    pre = raw.get("season_type") == "Pre Season"
    df = project(raw["lines"], season_logs(d), cfg)
    if df.empty:
        return {"date": d.isoformat(), "preseason": pre, "games": [], "players": [], "note": "No games on this date."}
    start = {int(k): v for k, v in raw["starters"].items()}
    owner, own_pct, inj, side = {}, {}, {}, {}
    if espn_state:
        me_id, opp_id = espn_state.get("me_id", 1), espn_state.get("opp_id")
        for tid, t in espn_state["teams"].items():
            tid = t.get("id", tid)
            for p in t["roster"]:
                owner[norm(p["name"])] = t["name"]
                inj[norm(p["name"])] = p["inj"]
                side[norm(p["name"])] = "me" if tid == me_id else "opp" if tid == opp_id else ""
        for f in espn_state["fa"]:
            own_pct[norm(f["name"])] = f["own"]
            inj[norm(f["name"])] = f["inj"]
    if owners:
        owner.update({k: v["team"] for k, v in owners["owner"].items()})
        side.update({k: v["side"] for k, v in owners["owner"].items()})
        own_pct.update(owners.get("pct", {}))
        inj.update(owners.get("inj", {}))
    # who sat out, per NBA team: rotation players (usual 18+ minutes) out are the "opening" behind a big night
    prior_min = _prior["MIN"]
    out_by_team, dnp_rows = {}, {}
    seen = set()
    for x in raw.get("dnp", []):
        if (x["game"], x["id"]) in seen:
            continue
        seen.add((x["game"], x["id"]))
        k = norm(x["name"])
        pm = prior_min.get(k, np.nan)
        dnp_rows.setdefault(x["game"], []).append({"name": x["name"], "team": x["team"], "reason": x["reason"] or "", "usual_min": None if pd.isna(pm) else round(float(pm)),
                                                   "owner": owner.get(k), "side": side.get(k, "")})
        if not pd.isna(pm) and pm >= 18 and not pre:        # preseason: starters sit as a rule, so their absence says nothing about the others
            out_by_team.setdefault(x["team"], []).append(f"{x['name']} ({pm:.0f} mpg)")
    df["rank"] = df["V"].rank(ascending=False, method="min").astype(int)
    df["foul_trouble"] = (df["PF"] >= 5) | (df["PF"] / df["MIN"].clip(lower=1) * 36 >= 6.5)
    gm = {gid: abs(list(m["pts"].values())[0] - list(m["pts"].values())[1]) for gid, m in raw["games"].items() if len(m["pts"]) == 2}
    df["blow"] = df["GAME_ID"].map(gm).fillna(0) >= 20
    df = df.sort_values("V", ascending=False)
    rows = []
    for r in df.to_dict("records"):
        k = norm(r["PLAYER_NAME"])
        stt = start.get(int(r["PLAYER_ID"]), (False, ""))
        zc = {c: round(float(r[f"z_{c}"]), 2) for c in cfg["cats"]}
        mates = out_by_team.get(r["TEAM_ABBREVIATION"], [])
        uu = _usual_usg.get(k)
        r["dusg"] = None if uu is None else float(r["usg"]) - uu
        tag, reasons = verdict(r, owner.get(k), own_pct.get(k), pre, mates, sc)
        if tag == "FLUKE" and owner.get(k):
            tag = "NOISE"                                   # already on a roster: the point is the big night changes nothing
        best = [c for c in sorted(zc, key=lambda c: -zc[c])[:4] if c not in ("pf", "to")]
        fits = [cfg["label"][c] for c in best if tag in ("PICKUP", "WATCH") and need_cats and c in need_cats and zc[c] > 0.5]
        m = raw["games"][r["GAME_ID"]]
        rows.append({"rank": int(r["rank"]), "name": r["PLAYER_NAME"], "team": r["TEAM_ABBREVIATION"], "game": m["matchup"], "gid": r["GAME_ID"], "start": bool(stt[0]),
                     "pos": r.get("POS") or stt[1], "min": round(float(r["min"]), 1), "pts": int(r["PTS"]), "fg3": int(r["FG3M"]), "reb": int(r["OREB"] + r["DREB"]),
                     "ast": int(r["AST"]), "stl": int(r["STL"]), "blk": int(r["BLK"]), "fgm": int(r["FGM"]), "fga": int(r["FGA"]), "ftm": int(r["FTM"]),
                     "fta": int(r["FTA"]), "to": int(r["TOV"]), "pf": int(r["PF"]), "pm": int(r["PLUS_MINUS"]), "value": round(float(r["V"]), 2),
                     "neutral": round(float(r["N"]), 2), "luck": round(float(r["L"]), 2), "usg": round(float(r["usg"]), 1),
                     "dusg": None if r["dusg"] is None else round(r["dusg"], 1), "foul": bool(r["foul_trouble"]),
                     "proj": None if pd.isna(r["proj"]) else round(float(r["proj"]), 2), "dmin": None if pd.isna(r["dmin"]) else round(float(r["dmin"]), 1),
                     "z": zc, "verdict": tag, "reasons": reasons, "owner": owner.get(k), "side": side.get(k, ""), "own_pct": own_pct.get(k), "inj": inj.get(k, ""),
                     "mates_out": mates[:3], "fits": fits})
    games = [{"gid": gid, "matchup": g["matchup"], "score": " - ".join(f"{t} {p}" for t, p in g["pts"].items()),
              "margin": gm.get(gid), "blowout": bool(gm.get(gid, 0) >= 20), "dnp": sorted(dnp_rows.get(gid, []), key=lambda x: -(x["usual_min"] or 0))}
             for gid, g in raw["games"].items()]
    return {"date": d.isoformat(), "preseason": pre, "games": games, "players": rows, "cats": cfg["cats"], "labels": [cfg["label"][c] for c in cfg["cats"]],
            "weights": cfg["w"], "n_cats": cfg["n"],
            "note": ("Preseason: rotations/minutes unreliable; verdicts are capped at WATCH. " if pre else "") +
                    "Model: walk-forward, test R2 0.55 for next-10-game Value (prior only: 0.44).",
            "model": {"luck_persistence": cfg["model"].get("luck_persistence"), "min_jump_per_minute": cfg["model"]["coef"]["dmin"], "report": cfg["model"].get("report")}}


if __name__ == "__main__":
    d = date.fromisoformat(sys.argv[1]) if len(sys.argv) > 1 else date(2026, 10, 13)
    res = build_daily(d)
    print(res["date"], "preseason" if res["preseason"] else "regular", len(res["players"]), "players;", res["note"])
    for p in res["players"][:14]:
        print(f"#{p['rank']:3d} {p['name']:24s} {p['team']} {'S' if p['start'] else ' '} {p['min']:5.1f}m {p['pts']:2d}p {p['reb']:2d}r {p['ast']:2d}a "
              f"V={p['value']:6.2f} luck={p['luck']:+5.2f} proj10={p['proj']} dmin={p['dmin']} -> {p['verdict']}  {'; '.join(p['reasons'])[:110]}")
    from collections import Counter
    print(Counter(p["verdict"] for p in res["players"]))
