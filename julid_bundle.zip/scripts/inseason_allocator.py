"""Weekly start allocator for the Lapis league: which player-games to START, given the 33 (+7 Sunday) cap.

League rule (confirmed by user 2026-10-06):
  * 7 starting slots per day: PG SG SF PF C UTIL UTIL; 5 bench; a start only counts if the player plays > 0 minutes
  * Mon-Sat: at most 33 counted starts. If Mon-Sat <= 33, Sunday opens with up to 7 more starts. If Mon-Sat > 33, Sunday = 0.

Why a greedy solution is exactly optimal (for the planned/expected-value problem):
  each day's feasible lineups form a transversal matroid (slot matching), the days combine as a direct sum, and the
  Mon-Sat cap of 33 is a truncation of that matroid -- still a matroid. Greedy by value is therefore optimal. Sunday is an
  independent matroid because staying at <= 33 always keeps it open. test_inseason.py checks this against brute force.

Uncertainty: a start uses cap only if the player actually plays, so each start costs p_play of the cap in expectation.
plan_week() plans on expected cap use (cap - buffer) and simulate() reports P(Mon-Sat > cap), which is the cliff that
costs Sunday. Overage games still COUNT (confirmed, OVERAGE_COUNTS), so the best of two plans is returned:
A) at most 33 Mon-Sat + Sunday, B) no cap Mon-Sat and no Sunday (B only differs from A when it wants more than 33).
"""
import sys
from itertools import product

import numpy as np

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SLOTS = ["PG", "SG", "SF", "PF", "C", "UTIL", "UTIL"]
POS = {"PG", "SG", "SF", "PF", "C"}
CAP, SUN_CAP = 33, 7
OVERAGE_COUNTS = True    # confirmed by user 2026-10-06: Mon-Sat games beyond 33 DO count (34 counts 34, 35 counts 35); only Sunday is lost
SUN = 6


def parse_elig(s):
    """'PG,SG,G' / 'F' / ['C'] -> set of PG/SG/SF/PF/C."""
    toks = s if isinstance(s, (list, set, tuple)) else str(s).replace("/", ",").split(",")
    out = set()
    for t in toks:
        t = t.strip().upper()
        if t in POS:
            out.add(t)
        elif t == "G":
            out |= {"PG", "SG"}
        elif t == "F":
            out |= {"SF", "PF"}
    return out or set(POS)


def can_fill(elig_list):
    """True if every player in elig_list (list of sets) can be assigned a distinct slot of the 7."""
    if len(elig_list) > len(SLOTS):
        return False
    match = [-1] * len(SLOTS)

    def aug(i, seen):
        for s, name in enumerate(SLOTS):
            if s in seen or not (name == "UTIL" or name in elig_list[i]):
                continue
            seen.add(s)
            if match[s] == -1 or aug(match[s], seen):
                match[s] = i
                return True
        return False

    return all(aug(i, set()) for i in range(len(elig_list)))


def assign_slots(elig_by_player):
    """dict player -> elig set for ONE day's starters -> dict slot_index -> player (or None if infeasible)."""
    names = list(elig_by_player)
    match = [-1] * len(SLOTS)

    def aug(i, seen):
        for s, name in enumerate(SLOTS):
            if s in seen or not (name == "UTIL" or name in elig_by_player[names[i]]):
                continue
            seen.add(s)
            if match[s] == -1 or aug(match[s], seen):
                match[s] = i
                return True
        return False

    if not all(aug(i, set()) for i in range(len(names))):
        return None
    return {SLOTS[s] + ("" if SLOTS[s] != "UTIL" else str(s - 4)): names[i] for s, i in enumerate(match) if i != -1}


def _greedy(items, elig, n_days, cap, floor):
    """items: list of (value, p_play, player, day). Returns chosen list. cap=None means no cap."""
    chosen, per_day, used = [], [[] for _ in range(n_days)], 0.0
    for v, p, name, d in sorted(items, key=lambda x: -x[0] * x[1]):    # expected value: a slot is the scarce thing
        if v * p <= floor:
            break
        if cap is not None and used + p > cap + 1e-9:
            continue
        if not can_fill([elig[n] for n in per_day[d]] + [elig[name]]):
            continue
        per_day[d].append(name)
        chosen.append((name, d, v, p))
        used += p
    return chosen


def plan_week(players, play_days, weeks_days=None, cap=CAP, sun_cap=SUN_CAP, buffer=0.0, floor=0.0,
              overage_counts=OVERAGE_COUNTS, n_days=7, sun_day=SUN, sunday_open=True):
    """players: dict name -> dict(elig=set, value=float per game, p=P(plays>0min | team has game), team=str)
    play_days: dict team -> set of day indexes (0..n_days-1) the team plays.  value is the per-game utility (e.g. weighted z).
    weeks_days: the day indexes still open to plan (default all); cap = REMAINING Mon-Sat cap; sun_day = index of the Sunday
    that is lost when over the cap (None for a period with no such day); sunday_open=False when the cap is already blown.
    Returns dict(starts=[(name, day, value, p)], exp_value, exp_cap_use, mode, sun_day)."""
    elig = {n: set(d["elig"]) for n, d in players.items()}
    open_days = set(range(n_days)) if weeks_days is None else set(weeks_days)
    items = [(d.get("vday", {}).get(day, d["value"]), d.get("pday", {}).get(day, d["p"]), n, day) for n, d in players.items()
             for day in play_days.get(d["team"], ()) if day in open_days]
    mon_sat = [it for it in items if it[3] != sun_day]
    sun = [it for it in items if it[3] == sun_day] if sunday_open else []
    if not sunday_open:                                           # cap already exceeded: every remaining game counts, Sunday is gone
        return _pack(_greedy(mon_sat, elig, n_days, None, floor), "over cap (Sunday locked)", sun_day)
    a_ms = _greedy(mon_sat, elig, n_days, cap - buffer, floor)
    a_sun = (_greedy(sun, elig, n_days, None, floor) if sun_cap else [])[:sun_cap]
    planA = a_ms + a_sun
    best, mode = planA, "cap+sunday"
    if overage_counts:
        b_ms = _greedy(mon_sat, elig, n_days, None, floor)        # play everything good Mon-Sat; Sunday is locked once over the cap
        b_use = sum(p for *_, p in b_ms)
        if b_use > cap and sum(v * p for _, _, v, p in b_ms) > sum(v * p for _, _, v, p in planA):
            best, mode = b_ms, "all-in (Sunday locked)"
    return _pack(best, mode, sun_day)


def _pack(starts, mode, sun_day):
    return {"starts": starts, "exp_value": sum(v * p for _, _, v, p in starts),
            "exp_cap_use": sum(p for _, d, _, p in starts if d != sun_day), "mode": mode, "sun_day": sun_day}


def simulate(plan, n=4000, cap=CAP, seed=1):
    """Monte Carlo of whether starts actually play. Returns P(Mon-Sat counted starts > cap), mean counted starts, mean value."""
    rng = np.random.default_rng(seed)
    st = plan["starts"]
    sd = plan.get("sun_day", SUN)
    p = np.array([s[3] for s in st]); sat = np.array([s[1] != sd for s in st]); v = np.array([s[2] for s in st])
    plays = rng.random((n, len(st))) < p
    ms = (plays & sat).sum(axis=1)
    over = ms > cap
    val = (plays * v).sum(axis=1)
    if len(st):
        sun_val = (plays * v * ~sat).sum(axis=1)
        val = val - np.where(over, sun_val, 0.0)       # Sunday locked when over the cap
    return {"p_over": float(over.mean()), "mean_ms_starts": float(ms.mean()), "mean_value": float(val.mean())}


def choose_buffer(players, play_days, buffers=(0, 0.5, 1, 1.5, 2, 3, 4), **kw):
    """Pick the cap buffer that maximises simulated value (accounts for the Sunday cliff). Returns (best_buffer, table)."""
    rows = []
    for b in buffers:
        pl = plan_week(players, play_days, buffer=b, **kw)
        s = simulate(pl)
        rows.append((b, pl["exp_cap_use"], s["p_over"], s["mean_value"]))
    return max(rows, key=lambda r: r[3])[0], rows


def brute_force(players, play_days, cap, sun_cap, floor=0.0, days=range(7)):
    """Exhaustive optimum of deterministic version (p=1) for tiny instances -- used only by tests."""
    elig = {n: set(d["elig"]) for n, d in players.items()}
    items = [(d["value"], n, day) for n, d in players.items() for day in play_days.get(d["team"], ()) if day in days]
    best = -1e18
    for mask in product([0, 1], repeat=len(items)):
        sel = [it for it, m in zip(items, mask) if m]
        ms = [it for it in sel if it[2] != SUN]
        su = [it for it in sel if it[2] == SUN]
        if len(ms) > cap or len(su) > sun_cap:
            continue
        ok = True
        for d in range(7):
            names = [n for _, n, dd in sel if dd == d]
            if names and not can_fill([elig[n] for n in names]):
                ok = False
                break
        if ok:
            best = max(best, sum(v for v, _, _ in sel))
    return best
