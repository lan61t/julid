"""Per-game Value in the Yahoo Julid league's 9 categories (FG% FT% 3PM PTS REB AST STL BLK TO), same construction as inseason_value.py:
z over the draftable pool (Q), REB = OREB + DREB with its own sd, % cats as volume-weighted impact, TO sign-flipped, categories weighted by the
G-score reliability ratios (the 13-cat ratios mapped to 9 cats the way julid_engine.BAL9 does). 0 = an average draftable player.

SCALE_VS_13 = how much smaller / larger a typical 9-cat Value is than a 13-cat Value (sd over the draftable pool): thresholds that were set on
the 13-cat scale (Must pick up gain, 'playable' floor, ...) are multiplied by it.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_value as IV  # noqa: E402

CATS9 = ["fg_pct", "ft_pct", "3pm", "pts", "reb", "ast", "stl", "blk", "to"]
_c13 = {c: i for i, c in enumerate(G.CATS13)}


def _map13(a):
    a = np.asarray(a, dtype=float)
    return np.array([a[_c13["fg_pct"]], a[_c13["ft_pct"]], a[_c13["3pm"]], a[_c13["pts"]], 0.5 * (a[_c13["oreb"]] + a[_c13["dreb"]]),
                     a[_c13["ast"]], a[_c13["stl"]], a[_c13["blk"]], a[_c13["to"]]])


BAL9 = _map13(G.RATIO)
_RHO = {}


def reb_sd(Q):
    """sd of OREB + DREB in the pool: var = sd_o^2 + sd_d^2 + 2 rho sd_o sd_d, rho taken once from julid_engine's 2025-26 pool sd."""
    so, sd_ = Q["sd"]["oreb"], Q["sd"]["dreb"]
    if "rho" not in _RHO:
        import julid_engine as J
        s = J.SD["reb"]
        from inseason_live import Q as Q25
        a, b = Q25["sd"]["oreb"], Q25["sd"]["dreb"]
        _RHO["rho"] = (s * s - a * a - b * b) / (2 * a * b)
    return float(np.sqrt(so * so + sd_ * sd_ + 2 * _RHO["rho"] * so * sd_))


def value_frame9(df, Q):
    """9 z columns (CATS9 order) + 'value'. df needs MIN-free box columns FGM FGA FG3M FTM FTA OREB DREB AST TOV STL BLK PTS."""
    z = pd.DataFrame(index=df.index)
    for c, col in (("pts", "PTS"), ("stl", "STL"), ("blk", "BLK"), ("3pm", "FG3M"), ("ast", "AST")):
        z[c] = (df[col] - Q["mean"][c]) / Q["sd"][c]
    z["to"] = -(df["TOV"] - Q["mean"]["to"]) / Q["sd"]["to"]
    z["reb"] = ((df["OREB"] + df["DREB"]) - (Q["mean"]["oreb"] + Q["mean"]["dreb"])) / reb_sd(Q)
    for c, (a, b) in (("fg_pct", ("FGM", "FGA")), ("ft_pct", ("FTM", "FTA"))):
        imp = df[a] - Q["comp"][c] * df[b]
        z[c] = (imp - Q["imp_mean"][c]) / Q["imp_sd"][c]
    z = z[CATS9]
    z["value"] = (z[CATS9] * BAL9).sum(axis=1)
    return z


def neutral_value9(df, rates, Q):
    """Value with made shots replaced by shrunk prior rate x attempts (3P% is not a category here, but PTS and FTM still depend on it)."""
    n = IV.neutral_frame(df, rates, Q)
    return value_frame9(n, Q)["value"]


def u0_9():
    """sigma_units (julid_engine.sigma_units scale) of the average draftable player, so Value = sum(BAL9 * (u - u0))."""
    import julid_engine as J
    u = np.zeros(9)
    for i, c in enumerate(CATS9):
        if c in J.PCT:
            u[i] = J.Q["imp_mean"][c] / J.IMP_SD[c]
        else:
            u[i] = (-1 if c in J.LOWER_BETTER else 1) * (J.Q["mean"][c] if c != "reb" else J.Q["mean"]["oreb"] + J.Q["mean"]["dreb"]) / J.SD[c]
    return u


def scale_vs_13():
    """sd of 9-cat Value / sd of 13-cat Value over the draftable pool of the draft projections (pool_2026-27_v31.csv z-scores)."""
    p = pd.read_csv(G.ROOT / "data" / "pool_2026-27_v31.csv").drop_duplicates("PLAYER_NAME")
    p = p.sort_values("g_total", ascending=False).head(168)
    z13 = p[[f"z_{c}" for c in G.CATS13]].to_numpy(dtype=float)
    v13 = z13 @ G.RATIO
    zc = p[[f"z_{c}" for c in CATS9 if c != "reb"]].to_numpy(dtype=float)
    from inseason_live import Q
    zreb = (p["z_oreb"] * Q["sd"]["oreb"] + p["z_dreb"] * Q["sd"]["dreb"]) / reb_sd(Q)
    zz = pd.DataFrame(zc, columns=[c for c in CATS9 if c != "reb"])
    zz["reb"] = zreb.to_numpy()
    v9 = zz[CATS9].to_numpy() @ BAL9
    return float(np.std(v9) / np.std(v13))


if __name__ == "__main__":
    print("BAL9", BAL9.round(3), "scale vs 13-cat", round(scale_vs_13(), 3))
