"""21-season pattern research (2005-06..2025-26) for the 13-category league:

  A. Roster effects   - vacated minutes / incoming talent -> incumbents' minutes & value
  B. Coach effects    - head-coach change -> pace, minutes concentration, young-player
                        minutes, incumbents' value; coach-level style persistence
  C. Team-status      - tanking vs contending -> games played, minutes, late-season
                        (last-20-games) availability and production, by age
  D. Other            - league-wide regime shifts (load management, pace, 3PA), age curve
  E. Backtest         - how well the project's projection recipe (recency-weighted blend,
                        availability-aware) predicts NEXT season, vs naive baselines

All value numbers use the same 13-category z-score idea as build_valuation.py
(percentage cats volume-weighted, TO/PF sign-flipped), recomputed per season on the
rotation pool (GP>=20, MIN>=15). Output tables -> data/research/*.csv.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
LONG = ROOT / "data" / "raw" / "long"
OUTD = ROOT / "data" / "research"
OUTD.mkdir(parents=True, exist_ok=True)
SEASONS = [f"{y}-{str(y + 1)[2:]}" for y in range(2005, 2025 + 1)]
pd.set_option("display.width", 200)


# ------------------------------------------------------------------ panel build
def season_values(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    pool = df[(df["GP"] >= 20) & (df["MIN"] >= 15)]
    z = pd.DataFrame(index=df.index)
    for c, col in [("pts", "PTS"), ("stl", "STL"), ("blk", "BLK"), ("oreb", "OREB"), ("dreb", "DREB"),
                   ("3pm", "FG3M"), ("ftm", "FTM"), ("ast", "AST")]:
        z[c] = (df[col] - pool[col].mean()) / pool[col].std()
    for c, made, att in [("fg", "FGM", "FGA"), ("3p", "FG3M", "FG3A"), ("ft", "FTM", "FTA")]:
        avg = pool[made].sum() / pool[att].sum()
        imp = (df[made] / df[att].replace(0, np.nan)).fillna(avg) * df[att] - avg * df[att]
        pimp = imp.loc[pool.index]
        z[c + "_pct"] = (imp - pimp.mean()) / pimp.std()
    for c, col in [("to", "TOV"), ("pf", "PF")]:
        z[c] = -(df[col] - pool[col].mean()) / pool[col].std()
    df["value"] = z.sum(axis=1)
    df["value9"] = z.drop(columns=["pf", "3p_pct"]).sum(axis=1)  # BBM-like 9-cat-ish proxy
    df["usg"] = df["FGA"] + 0.44 * df["FTA"] + df["TOV"]
    return df


def load_all():
    players, teams = [], []
    for i, s in enumerate(SEASONS):
        p = LONG / f"players_{s}.csv"
        t = LONG / f"teams_{s}.csv"
        if not (p.exists() and t.exists()):
            continue
        d = season_values(pd.read_csv(p))
        d["season"], d["si"] = s, i
        l20 = LONG / f"players_last20_{s}.csv"
        if l20.exists():
            l = pd.read_csv(l20)[["PLAYER_ID", "GP", "MIN", "PTS"]].rename(
                columns={"GP": "GP20", "MIN": "MIN20", "PTS": "PTS20"})
            d = d.merge(l, on="PLAYER_ID", how="left")
        tm = pd.read_csv(t)[["TEAM_ID", "GP", "W_PCT", "PACE", "OFF_RATING", "NET_RATING"]]
        tm = tm.rename(columns={"GP": "TEAM_GP"})
        tm["season"], tm["si"] = s, i
        tm["win_rank"] = tm["W_PCT"].rank(ascending=False, method="first")
        tm["tier"] = np.where(tm["win_rank"] <= 8, "contender", np.where(tm["win_rank"] > 22, "bottom", "middle"))
        players.append(d)
        teams.append(tm)
    P = pd.concat(players, ignore_index=True)
    T = pd.concat(teams, ignore_index=True)
    P = P.merge(T[["TEAM_ID", "si", "TEAM_GP", "W_PCT", "PACE", "NET_RATING", "tier", "win_rank"]],
                on=["TEAM_ID", "si"], how="left")
    P["gp_pct"] = (P["GP"] / P["TEAM_GP"]).clip(upper=1)
    P["gp_pct20"] = (P["GP20"] / 20).clip(upper=1)
    return P, T


def ols(y, X, names):
    X = np.column_stack([np.ones(len(y))] + [X[:, i] for i in range(X.shape[1])])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    res = y - X @ beta
    dof = max(len(y) - X.shape[1], 1)
    cov = np.linalg.inv(X.T @ X) * (res @ res / dof)
    se = np.sqrt(np.diag(cov))
    out = pd.DataFrame({"coef": beta, "t": beta / se}, index=["const"] + names)
    out["r2"] = 1 - (res @ res) / ((y - y.mean()) @ (y - y.mean()))
    return out.round(3)


def link_prev(P):
    """Each player-season linked to the same player's previous-season row."""
    prev = P[["PLAYER_ID", "si", "TEAM_ID", "MIN", "GP", "gp_pct", "value", "usg", "AGE", "FGA", "tier", "PACE"]].copy()
    prev["si"] += 1
    prev = prev.rename(columns={c: f"p_{c}" for c in prev.columns if c not in ("PLAYER_ID", "si")})
    return P.merge(prev, on=["PLAYER_ID", "si"], how="inner")


def roster_features(P):
    """Per team-season: vacated minute share, incoming/outgoing talent."""
    rows = []
    byk = {k: g for k, g in P.groupby(["TEAM_ID", "si"])}
    for (tid, si), cur in byk.items():
        prev = byk.get((tid, si - 1))
        if prev is None:
            continue
        pm = (prev["MIN"] * prev["GP"])
        base = pm.sum()
        departed = prev[~prev["PLAYER_ID"].isin(cur["PLAYER_ID"])]
        incomers = cur[~cur["PLAYER_ID"].isin(prev["PLAYER_ID"])]
        # incomers' value from THEIR previous season (any team)
        pv = P[(P["si"] == si - 1) & (P["PLAYER_ID"].isin(incomers["PLAYER_ID"]))]
        rows.append({
            "TEAM_ID": tid, "si": si,
            "vacated_share": (departed["MIN"] * departed["GP"]).sum() / base if base else np.nan,
            "vacated_usg_share": (departed["usg"] * departed["GP"]).sum() / (prev["usg"] * prev["GP"]).sum(),
            "out_talent": departed["value"].clip(lower=0).sum(),
            "in_talent": pv["value"].clip(lower=0).sum(),
        })
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ analyses
def a_roster(L, RF):
    print("\n=== A. ROSTER EFFECTS ===")
    X = L.merge(RF, on=["TEAM_ID", "si"], how="left")
    inc = X[(X["p_TEAM_ID"] == X["TEAM_ID"]) & (X["p_MIN"] >= 15) & (X["p_GP"] >= 30)].dropna(subset=["vacated_share"])
    inc = inc.assign(dMIN=inc["MIN"] - inc["p_MIN"], dval=inc["value"] - inc["p_value"],
                     dusg=inc["usg"] - inc["p_usg"], net_talent=inc["in_talent"] - inc["out_talent"])
    inc["vq"] = pd.qcut(inc["vacated_share"], 5, labels=["Q1 low", "Q2", "Q3", "Q4", "Q5 high"])
    t = inc.groupby("vq", observed=True)[["dMIN", "dusg", "dval"]].agg(["mean", "count"]).round(2)
    print("Incumbents (same team both years, prev MIN>=15): change by VACATED-minutes quintile")
    print(t.to_string())
    inc["nq"] = pd.qcut(inc["net_talent"], 5, labels=["Q1 talent LOST", "Q2", "Q3", "Q4", "Q5 talent ADDED"])
    t2 = inc.groupby("nq", observed=True)[["dMIN", "dusg", "dval"]].mean().round(2)
    print("\nIncumbents: change by NET TALENT (incoming - outgoing value) quintile")
    print(t2.to_string())
    r = ols(inc["dval"].to_numpy(), inc[["p_value", "p_AGE", "p_MIN", "vacated_share", "net_talent"]].to_numpy(),
            ["prev_value", "prev_age", "prev_min", "vacated_share", "net_talent"])
    print("\nOLS dValue ~ ...  (incumbents)\n" + r.to_string())
    r2 = ols(inc["dMIN"].to_numpy(), inc[["p_value", "p_AGE", "p_MIN", "vacated_share", "net_talent"]].to_numpy(),
             ["prev_value", "prev_age", "prev_min", "vacated_share", "net_talent"])
    print("\nOLS dMIN ~ ...\n" + r2.to_string())
    mov = X[(X["p_TEAM_ID"] != X["TEAM_ID"]) & (X["p_MIN"] >= 15) & (X["p_GP"] >= 30)]
    mov = mov.assign(dval=mov["value"] - mov["p_value"], dMIN=mov["MIN"] - mov["p_MIN"])
    stay = inc
    print(f"\nTeam changers n={len(mov)}: mean dValue {mov['dval'].mean():.2f}, dMIN {mov['dMIN'].mean():.2f} | "
          f"stayers n={len(stay)}: dValue {stay['dval'].mean():.2f}, dMIN {stay['dMIN'].mean():.2f}")
    # control for prior value (regression to the mean) on team-change
    both = pd.concat([mov.assign(moved=1), stay.assign(moved=0)])
    rr = ols(both["dval"].to_numpy(), both[["p_value", "p_AGE", "moved"]].to_numpy(), ["prev_value", "prev_age", "moved"])
    print("OLS dValue ~ prev_value + age + moved (controls for regression to the mean)\n" + rr.to_string())
    t.to_csv(OUTD / "roster_vacated_quintiles.csv")


def a_coach(P, L, T):
    print("\n=== B. COACH EFFECTS ===")
    cpath = LONG / "coaches.csv"
    if not cpath.exists():
        print("coaches.csv not available yet -> skipped"); return
    C = pd.read_csv(cpath)
    C["si"] = C["SEASON_LABEL"].map({s: i for i, s in enumerate(SEASONS)})
    cs = C.groupby(["TEAM_ID", "si"])["COACH_ID"].apply(set).reset_index(name="hc")
    if cs["si"].nunique() < 15:
        print(f"coach data covers only {cs['si'].nunique()} seasons so far -> skipped"); return
    prev = cs.copy(); prev["si"] += 1; prev = prev.rename(columns={"hc": "hc_prev"})
    cc = cs.merge(prev, on=["TEAM_ID", "si"])
    cc["coach_changed"] = [len(a & b) == 0 for a, b in zip(cc["hc"], cc["hc_prev"])]
    print(f"team-seasons with coach data: {len(cs)}, with a previous season: {len(cc)}, coach changes: {cc['coach_changed'].sum()}")
    # team-level
    tp = T[["TEAM_ID", "si", "PACE", "NET_RATING", "W_PCT"]].copy()
    pp = tp.copy(); pp["si"] += 1; pp = pp.rename(columns={c: f"p_{c}" for c in ("PACE", "NET_RATING", "W_PCT")})
    tt = cc.merge(tp, on=["TEAM_ID", "si"]).merge(pp, on=["TEAM_ID", "si"])
    tt["dPACE"] = tt["PACE"] - tt["p_PACE"]
    # minutes concentration: avg MPG of top-5 by minutes
    top5 = P.sort_values("MIN", ascending=False).groupby(["TEAM_ID", "si"]).head(5).groupby(["TEAM_ID", "si"])["MIN"].mean().rename("top5mpg").reset_index()
    t5p = top5.copy(); t5p["si"] += 1; t5p = t5p.rename(columns={"top5mpg": "p_top5mpg"})
    tt = tt.merge(top5, on=["TEAM_ID", "si"]).merge(t5p, on=["TEAM_ID", "si"])
    tt["dTop5"] = tt["top5mpg"] - tt["p_top5mpg"]
    g = tt.groupby("coach_changed")[["dPACE", "dTop5"]].agg(["mean", lambda x: x.abs().mean(), "count"]).round(2)
    g.columns = ["dPACE mean", "|dPACE| mean", "n", "dTop5MPG mean", "|dTop5MPG| mean", "n2"]
    print("Team pace & starter-minutes change: coach changed vs same coach\n" + g.to_string())
    # same coach persistence of starter minutes
    for flag in (False, True):
        s = tt[tt["coach_changed"] == flag]
        print(f"  corr(top5 MPG this yr, last yr) coach_changed={flag}: {np.corrcoef(s['top5mpg'], s['p_top5mpg'])[0, 1]:.2f} (n={len(s)})")
    # player-level
    X = L.merge(cc[["TEAM_ID", "si", "coach_changed"]], on=["TEAM_ID", "si"], how="inner")
    inc = X[(X["p_TEAM_ID"] == X["TEAM_ID"]) & (X["p_MIN"] >= 10) & (X["p_GP"] >= 30)].copy()
    inc["dval"] = inc["value"] - inc["p_value"]; inc["dMIN"] = inc["MIN"] - inc["p_MIN"]
    inc["dgp"] = inc["gp_pct"] - inc["p_gp_pct"]
    inc["grp"] = np.select([inc["p_AGE"] <= 23, inc["p_AGE"] >= 31], ["age<=23", "age>=31"], "age 24-30")
    t = inc.groupby(["grp", "coach_changed"]).agg(dMIN=("dMIN", "mean"), dval=("dval", "mean"),
                                                   dgp=("dgp", "mean"), n=("dval", "size")).round(3)
    print("\nIncumbents by age group & coach change (same team both years):")
    print(t.to_string())
    r = ols(inc["dval"].to_numpy(), inc[["p_value", "p_AGE", "coach_changed"]].astype(float).to_numpy(), ["prev_value", "prev_age", "coach_changed"])
    print("OLS dValue ~ prev_value + age + coach_changed\n" + r.to_string())
    r = ols(inc["dMIN"].to_numpy(), inc[["p_MIN", "p_AGE", "coach_changed"]].astype(float).to_numpy(), ["prev_min", "prev_age", "coach_changed"])
    print("OLS dMIN ~ prev_min + age + coach_changed\n" + r.to_string())
    # coach style table (>=4 seasons)
    cl = C.merge(P.groupby(["TEAM_ID", "si"]).apply(lambda g: pd.Series({
        "top5mpg": g.nlargest(5, "MIN")["MIN"].mean(),
        "star_gp": g.nlargest(3, "value")["gp_pct"].mean(),
        "young_min": g[g["AGE"] <= 22]["MIN"].sum() / max(g["MIN"].sum(), 1)}), include_groups=False).reset_index(),
        on=["TEAM_ID", "si"]).merge(T[["TEAM_ID", "si", "PACE"]], on=["TEAM_ID", "si"])
    agg = cl.groupby("COACH_NAME").agg(seasons=("si", "nunique"), top5mpg=("top5mpg", "mean"), star_gp=("star_gp", "mean"),
                                         pace=("PACE", "mean"), young_share=("young_min", "mean"))
    agg = agg[agg["seasons"] >= 6].round(3)
    print(f"\nCoach style, >=6 seasons (n={len(agg)}):")
    print("Heaviest starter minutes:\n" + agg.sort_values("top5mpg", ascending=False).head(6).to_string())
    print("Most star rest (lowest GP% of top-3 value players):\n" + agg.sort_values("star_gp").head(6).to_string())
    agg.to_csv(OUTD / "coach_style.csv")
    # persistence: does a coach's star_gp predict that coach's own star_gp next year on a DIFFERENT team? crude check
    cl = cl.sort_values(["COACH_ID", "si"])
    cl["next_star_gp"] = cl.groupby("COACH_ID")["star_gp"].shift(-1)
    cl["next_team"] = cl.groupby("COACH_ID")["TEAM_ID"].shift(-1)
    mv = cl[(cl["next_team"].notna()) & (cl["next_team"] != cl["TEAM_ID"])].dropna(subset=["next_star_gp"])
    if len(mv) > 20:
        print(f"Coach carries star-availability style to a NEW team? corr={np.corrcoef(mv['star_gp'], mv['next_star_gp'])[0, 1]:.2f} (n={len(mv)})")


def a_status(P):
    print("\n=== C. TANKING vs CONTENDING (team tier = final win-rank this season) ===")
    top = P[(P["MIN"] >= 15) & (P["GP"] >= 10)].copy()
    top["rank_v"] = top.groupby("si")["value"].rank(ascending=False)
    stars = top[top["rank_v"] <= 100].copy()
    stars["age_grp"] = np.select([stars["AGE"] <= 25, stars["AGE"] >= 31], ["<=25", ">=31"], "26-30")
    g = stars.groupby("tier")[["gp_pct", "MIN", "usg", "gp_pct20"]].mean().round(3)
    print("Top-100 value players: games played %, MPG, usage proxy, last-20-games availability, by team tier\n" + g.to_string())
    g2 = stars.groupby(["age_grp", "tier"])[["gp_pct", "gp_pct20"]].mean().round(3).unstack()
    print("\nAvailability by age and tier (gp_pct = full season, gp_pct20 = last 20 games):\n" + g2.to_string())
    stars = stars.assign(late_drop=stars["MIN20"] - stars["MIN"])
    g3 = stars.groupby("tier")["late_drop"].mean().round(2)
    print("\nLast-20 minus season MPG by tier (negative = late-season minutes cut):\n" + g3.to_string())
    # young / low-minute players on tankers
    young = P[(P["AGE"] <= 23) & (P["MIN"] >= 10)]
    print("\nPlayers age<=23 (MIN>=10): MPG and value by tier\n" +
          young.groupby("tier")[["MIN", "value", "usg"]].mean().round(2).to_string())
    stars.groupby(["age_grp", "tier"])[["gp_pct", "gp_pct20", "MIN", "late_drop"]].mean().round(3).to_csv(OUTD / "tier_availability.csv")


def a_other(P, T):
    print("\n=== D. OTHER REGIME SHIFTS / PATTERNS ===")
    rot = P[(P["MIN"] >= 15) & (P["GP"] >= 10)].copy()
    rot["rank_v"] = rot.groupby("si")["value"].rank(ascending=False)
    top50 = rot[rot["rank_v"] <= 50]
    yr = pd.DataFrame({
        "top50_gp_pct": top50.groupby("season")["gp_pct"].mean(),
        "top50_mpg": top50.groupby("season")["MIN"].mean(),
        "league_pace": T.groupby("season")["PACE"].mean(),
        "fg3a_pg_rot": rot.groupby("season")["FG3A"].mean(),
        "tov_pg_rot": rot.groupby("season")["TOV"].mean(),
        "pf_pg_rot": rot.groupby("season")["PF"].mean(),
    }).round(2)
    print(yr.to_string())
    yr.to_csv(OUTD / "regime_by_season.csv")
    # age curve: year-over-year value change by age (prev age), controlling regression to mean via prev value bins
    return yr


def a_backtest(P, L):
    print("\n=== E. BACKTEST of projection recipes (predict season t from seasons < t) ===")
    pv = P.pivot_table(index="PLAYER_ID", columns="si", values="value")
    pg = P.pivot_table(index="PLAYER_ID", columns="si", values="gp_pct")
    pm = P.pivot_table(index="PLAYER_ID", columns="si", values="MIN")
    rows = []
    W = np.array([0.5, 0.3, 0.15, 0.05])  # newest first; recency blend like the project's
    for t in range(6, len(SEASONS)):
        if SEASONS[t] in ("2019-20", "2020-21"):  # shortened/abnormal seasons distort GP%
            pass
        cand = pv.index[(pv[t - 1].notna()) & (pm[t - 1] >= 15)]
        cur = P[(P["si"] == t) & P["PLAYER_ID"].isin(cand)].set_index("PLAYER_ID")
        cand = [c for c in cand if c in cur.index and cur.loc[c, "GP"] >= 1]
        if len(cand) < 100:
            continue
        hist = pv.loc[cand, [t - 1, t - 2, t - 3, t - 4]]
        w = np.where(hist.notna().to_numpy(), W, 0)
        blend = (hist.fillna(0).to_numpy() * w).sum(axis=1) / w.sum(axis=1)
        last = hist[t - 1].to_numpy()
        eq3 = hist[[t - 1, t - 2, t - 3]].mean(axis=1).to_numpy()
        avail = pg.loc[cand, [t - 1, t - 2, t - 3]].mean(axis=1).fillna(0.7).clip(0.3, 1).to_numpy()
        realized_rate = cur.loc[cand, "value"].to_numpy()
        realized_total = realized_rate * cur.loc[cand, "gp_pct"].to_numpy()  # what the roster actually got
        cands = {"last_season": last, "equal_3yr": eq3, "recency_blend": blend,
                 "recency_x_avail": blend * avail}
        for name, proj in cands.items():
            sp_rate = pd.Series(proj).rank().corr(pd.Series(realized_rate).rank())
            sp_tot = pd.Series(proj).rank().corr(pd.Series(realized_total).rank())
            k = min(84, len(cand))
            pick = np.argsort(-proj)[:k]
            best = np.argsort(-realized_total)[:k]
            rows.append({"season": SEASONS[t], "method": name, "spearman_rate": sp_rate, "spearman_total": sp_tot,
                         "avg_realized_total_of_top84": realized_total[pick].mean(),
                         "top84_overlap": len(set(pick) & set(best)) / k})
    R = pd.DataFrame(rows)
    summ = R.groupby("method")[["spearman_rate", "spearman_total", "avg_realized_total_of_top84", "top84_overlap"]].mean().round(3)
    print(f"Average over {R['season'].nunique()} target seasons:\n" + summ.sort_values("avg_realized_total_of_top84", ascending=False).to_string())
    R.to_csv(OUTD / "backtest_projection.csv", index=False)

    # does adding contextual features help, out-of-sample? time-split OLS on delta value
    X = L.merge(roster_features(P), on=["TEAM_ID", "si"], how="left")
    X = X[(X["p_MIN"] >= 15) & (X["p_GP"] >= 30)].dropna(subset=["vacated_share"]).copy()
    X["d"] = X["value"] - X["p_value"]
    X["moved"] = (X["p_TEAM_ID"] != X["TEAM_ID"]).astype(float)
    X["net_talent"] = X["in_talent"] - X["out_talent"]
    X["tank_prev"] = (X["p_tier"] == "bottom").astype(float)
    X["young"] = (X["p_AGE"] <= 23).astype(float)
    train, test = X[X["si"] <= 14], X[X["si"] > 14]
    base_cols = ["p_value", "p_AGE", "p_MIN"]
    ctx_cols = base_cols + ["vacated_share", "net_talent", "moved", "tank_prev", "young"]
    for label, cols in (("baseline (prev value, age, minutes)", base_cols), ("+ roster/team context", ctx_cols)):
        Xtr = np.column_stack([np.ones(len(train))] + [train[c] for c in cols])
        beta, *_ = np.linalg.lstsq(Xtr, train["d"].to_numpy(), rcond=None)
        Xte = np.column_stack([np.ones(len(test))] + [test[c] for c in cols])
        pred = Xte @ beta
        mse = ((test["d"].to_numpy() - pred) ** 2).mean()
        print(f"  holdout MSE ({label}): {mse:.3f}   (naive 'no change' MSE {(test['d'] ** 2).mean():.3f}, "
              f"n_test={len(test)})")
        if label.startswith("+"):
            print("  coefficients: " + ", ".join(f"{c}={b:.3f}" for c, b in zip(["const"] + cols, beta)))
    return R


def main():
    P, T = load_all()
    print(f"panel: {len(P)} player-seasons over {P['season'].nunique()} seasons; teams rows {len(T)}")
    L = link_prev(P)
    RF = roster_features(P)
    want = set(sys.argv[1:]) or {"A", "B", "C", "D", "E"}
    if "A" in want: a_roster(L, RF)
    if "B" in want: a_coach(P, L, T)
    if "C" in want: a_status(P)
    if "D" in want: a_other(P, T)
    if "E" in want: a_backtest(P, L)


if __name__ == "__main__":
    main()
