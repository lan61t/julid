"""Build the Julid Daily phone page: one self-contained index.html (state embedded) + manifest/icon files.

    python scripts/build_julid_site.py [--out D:\\JH\\NBA\\julid\\site] [--week N]

Reads rosters.psv / free_agents.psv (snapshots read from Yahoo through Chrome), runs julid_engine.build_state, embeds the JSON in
julid_app_template.html. Publishing = upload index.html (and the small PWA files) to the repo root of lan61t/julid, Pages from branch main.
"""
import json
import os
import sys
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import inseason_live as L  # noqa: E402
import julid_engine as J  # noqa: E402

import struct  # noqa: E402
import zlib  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


# ---- app icons (plain PNG writer, no image libraries)
def png(size, bg=(43, 95, 217), fg=(255, 255, 255)):
    """A plain app icon: blue rounded square with a white ring and a bar (a stylised basketball), no image libraries needed."""
    rows = []
    c, r = (size - 1) / 2, size * 0.30
    for y in range(size):
        row = bytearray([0])
        for x in range(size):
            dx, dy = x - c, y - c
            inside = max(abs(dx), abs(dy)) <= size * 0.5 - 1 and (abs(dx) + abs(dy) <= size * 0.92 or (abs(dx) < size * 0.42 and abs(dy) < size * 0.42))
            d = (dx * dx + dy * dy) ** 0.5
            ring = abs(d - r) < size * 0.035
            bar = abs(dy) < size * 0.03 and d < r or abs(dx) < size * 0.03 and d < r
            px = fg if (ring or bar) else bg
            row += bytes(px + ((255,) if inside else (0,)))
        rows.append(bytes(row))
    raw = b"".join(rows)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


ICON_SVG = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="22" fill="#2b5fd9"/>'
            '<circle cx="50" cy="50" r="30" fill="none" stroke="#fff" stroke-width="4"/><path d="M50 20v60M20 50h60" stroke="#fff" stroke-width="4"/></svg>')
MANIFEST = {"name": "Julid Daily", "short_name": "Julid", "start_url": "./", "scope": "./", "display": "standalone", "background_color": "#0f1217",
            "theme_color": "#2b5fd9", "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
                                                {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
                                                {"src": "icon.svg", "sizes": "any", "type": "image/svg+xml"}]}



def _read(p):
    try:
        return Path(p).read_text(encoding="utf-8").strip()
    except Exception:
        return None


def bookmarklet():
    """The bookmarklet (refresh/bookmarklet.js) as a javascript: URL: it reads the Yahoo league from the signed-in browser and offers the
    data for pasting into data/yahoo.json on GitHub, which triggers the rebuild."""
    import re
    from urllib.parse import quote
    for p in (HERE.parent / "refresh" / "bookmarklet.js", Path(r"D:\JH\NBA\julid\refresh\bookmarklet.js")):
        if p.exists():
            src = "\n".join(l for l in p.read_text(encoding="utf-8").splitlines() if not l.strip().startswith("//"))
            return "javascript:" + quote(re.sub(r"\s+", " ", src).strip(), safe="()!*'~")
    return None


def backtest_text():
    f = J.ROOT / "data" / "research" / "winprob_backtest_9cat.json"
    if not f.exists():
        return None
    b = json.loads(f.read_text())
    w = b["as_is"]
    cats = b["platt_cat"]
    return (f"{b['n_matchups']:,} simulated matchups, {len(b['seasons'])} seasons, 12-team leagues: the engine's matchup chance scored Brier "
            f"{w['brier_win']:.3f} (0.25 = coin flip), favourites won {b['variance_inflation_table']['1.0']['hit_rate']*100:.0f}% of the time; "
            f"category chances scored {w['brier_cat']:.3f}. Matchup recalibration slope {b['platt_win']['a']:.2f} "
            f"(1.0 = perfectly honest); re-fitting it did not improve held-out seasons, so the page shows the raw chance. "
            f"Caveat: opponents were drafted by the same model, real managers may differ.")


def main():
    out = Path(sys.argv[sys.argv.index("--out") + 1]) if "--out" in sys.argv else Path(os.environ.get("JULID_SITE") or r"D:\JH\NBA\julid\site")
    week = int(sys.argv[sys.argv.index("--week") + 1]) if "--week" in sys.argv else None
    build(out, week)


def update_season_lines(today):
    """Store every finished 2026-27 game day's ESPN box lines (data/live/season_lines.csv) so projections blend with real games.
    Idempotent: inseason_daily.store_lines skips dates already stored. Returns warnings."""
    if today <= J.SEASON_START:
        return []
    warns = []
    try:
        import inseason_daily as D
        from datetime import timedelta
        d = J.SEASON_START
        have = set()
        if D.LINES.exists():
            import pandas as pd
            have = set(pd.read_csv(D.LINES, usecols=["GAME_DATE"])["GAME_DATE"].astype(str))
        while d < today:
            if d.isoformat() not in have:
                try:
                    D.fetch_day(d)
                except Exception as e:
                    warns.append(f"box scores for {d} not stored ({type(e).__name__}: {str(e)[:60]})")
            d += timedelta(days=1)
    except Exception as e:
        warns.append(f"season lines not updated ({type(e).__name__}: {str(e)[:80]})")
    return warns


def build(out, week=None):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    lines_warn = update_season_lines(date.today())
    st = J.build_state(week=week, today=date.today())
    st["warnings"] = list(st.get("warnings", [])) + lines_warn
    try:
        import julid_box as JB
        st["box"] = JB.build_box(st, J.load_rosters(), L.now_nba()[1])
        print("box scores:", st["box"]["dates"])
    except Exception as e:
        st["box"] = None
        st["warnings"] = st["warnings"] + [f"box scores not built ({type(e).__name__}: {str(e)[:80]})"]
    st["backtest"] = backtest_text()
    st["yahoo_ts"] = _read(J.RAW_DIR / "last_scrape_ts.txt")
    st["bookmarklet"] = bookmarklet()
    page = (HERE / "julid_app_template.html").read_text(encoding="utf-8").replace(
        "/*STATE*/null", json.dumps(L.jclean(st), allow_nan=False, ensure_ascii=False).replace("</", "<\\/"))
    (out / "index.html").write_text(page, encoding="utf-8")
    (out / "box.json").write_text(json.dumps(L.jclean(st["box"]), allow_nan=False), encoding="utf-8")   # the open page polls this, no reload needed
    man = dict(MANIFEST, name="Julid Daily", short_name="Julid")
    (out / "manifest.webmanifest").write_text(json.dumps(man), encoding="utf-8")
    (out / "icon.svg").write_text(ICON_SVG, encoding="utf-8")
    for s in (180, 192, 512):
        (out / f"icon-{s}.png").write_bytes(png(s))
    (out / ".nojekyll").write_text("", encoding="utf-8")
    print(f"built {out / 'index.html'} ({len(page) // 1024} KB): week {st['week']} P(win) {st['p_win']:.1%}")
    return st


if __name__ == "__main__":
    main()
