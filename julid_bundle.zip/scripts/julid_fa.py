"""Free-agent tiers (MUST / STREAM / WATCH / SKIP) and the Breakout radar for the Yahoo Julid league (12 teams, 9 categories, 10 starting
slots, 100 adds for the season). It is inseason_fa.py switched to the 9-category Value (julid_value.py) and the 9-category breakout model
(research_breakout.py --cats9 -> data/research/breakout_model_9cat.json).

Differences from the ESPN Lapis list:
  * Value is on a different scale (9 cats instead of 13): every Value threshold is multiplied by the model's scale_vs_13 (about 0.77)
  * 10 starters play every day with no games cap, so a MUST has to beat one of my top 10 (not 9) and depth counts 10 full + 3 bench places
  * there is no league-specific daily model, so the breakout model's next-10 estimate is used where the ESPN list uses the daily model
  * adds are a season budget (100), not a weekly limit: the STREAM tier is only offered while adds remain
"""
import sys
from pathlib import Path
from statistics import NormalDist

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402
import inseason_value as IV  # noqa: E402
import julid_engine as J  # noqa: E402
import julid_value as JV  # noqa: E402

DEPTH_9 = [1.0] * 10 + [0.5, 0.3, 0.15]          # 10 starters every day, then the 3 bench places (injury cover, matchup swaps)


def _rescore(pr, D):
    """Box lines from inseason_daily.project() carry 13-cat V / N / L: recompute them in 9 cats. Prior Value only where it comes from a real
    last season (the preseason-projection fallback is a 13-cat G-score: those players are treated as rookies by the breakout model)."""
    pr = pr.copy()
    pr["V"] = JV.value_frame9(pr, L.Q)["value"].to_numpy()
    rates = pd.DataFrame({c: pr["k"].map(D._rates[c]).fillna(L.Q["comp"][c]) for c in IV.PCT_COL})
    pr["N"] = JV.neutral_value9(pr, rates, L.Q).to_numpy()
    pr["L"] = pr["V"] - pr["N"]
    prior9 = JV.value_frame9(D._prior, L.Q)["value"]
    pr["prior_v"] = np.where(pr["prior_src"] == "last season", pr["k"].map(prior9), np.nan)
    pr["proj"] = np.nan
    return pr


def configure():
    FA.configure(J.CATS, J.LABEL, J.BAL9, JV.u0_9(), "breakout_model_9cat.json", rescore=_rescore, proj_from_model=True,
                 depth=DEPTH_9, must_rank=10)


def team_z(power_row):
    """z-like strength per category from the league table's 'chance to beat an average team' (0.5 = average)."""
    inv = {v: k for k, v in J.LABEL.items()}
    nd = NormalDist()
    return {inv[lab]: nd.inv_cdf(float(np.clip(p, 0.02, 0.98))) for lab, p in power_row["cat_p"].items()}


def fa_block(me, fa, wk, stream_rows, power_me, today, adds_left):
    configure()
    return FA.build_fa(me, fa, wk, stream_rows, set(), None, today, adds_left, my_z=team_z(power_me))
