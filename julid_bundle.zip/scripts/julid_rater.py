"""Player rater and roster analysis for the Yahoo Julid league (9 categories), using YAHOO's own player ranks, never ESPN's.

Yahoo's Players page lists two ranks per player: "Pre-Season" (Yahoo's projection for this season) and "Current" (its live rank from this
season's stats). Before the regular season starts Yahoo's "Current" is still last season's, so the page shows Pre-Season until the season
begins (SEASON_START) and Current afterwards. The scrape (refresh/scrape.js) saves them in data/raw/ranks.json.
Ours = the engine's per-game projection in the 9 league categories (0 = average draftable player, TO negative when high), ranked by total
among the ranked players we can project. Rank diff = Yahoo rank - our rank (positive = we rank him higher).
"""
import json
import sys
from datetime import date
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402
import julid_engine as J  # noqa: E402
import julid_fa as JF  # noqa: E402


def _pg(r):
    g = lambda c: float(r[J.CI[c]])
    return {"fg_pct": g("fgm") / max(g("fga"), 1e-9), "ft_pct": g("ftm") / max(g("fta"), 1e-9), "3pm": g("3pm"), "pts": g("pts"), "reb": g("reb"),
            "ast": g("ast"), "stl": g("stl"), "blk": g("blk"), "to": g("to")}


def load_ranks(path=None):
    try:
        j = json.loads(Path(path or J.RAW_DIR / "ranks.json").read_text(encoding="utf-8"))
        return j.get("rows", []), j.get("ts")
    except Exception:
        return [], None


def build(teams, proj, today, warnings):
    rows_in, ts = load_ranks()
    if not rows_in:
        warnings.append("Yahoo player ranks not in the scrape yet (run the refresh once): Player rater and ranks are empty")
        return None, None
    JF.configure()
    u0 = FA.CFG["u0"]
    mode = "current" if today >= J.SEASON_START else "preseason"
    label = ("Yahoo's Current rank (this season so far)" if mode == "current"
             else "Yahoo's Pre-Season rank (its projection for 2026-27; its Current rank is still last season's until games are played)")
    owner = {}
    for tid, t in teams.items():
        for r in t["roster"]:
            owner[str(r["id"])] = (tid, t["name"], r)
    rows = []
    for x in rows_in:
        pr = J.projection_for(x["name"], proj)
        u = pg = None
        if pr is not None:
            r = J.consistent(J.r11(pr["r"]))
            u, pg = J.sigma_units(r) - u0, _pg(r)
        o = owner.get(x["pid"])
        rows.append({"id": x["pid"], "name": x["name"], "yahoo_rank": x["cur"] if mode == "current" else x["pre"], "yahoo_pre": x["pre"], "yahoo_cur": x["cur"],
                     "owner": o[1] if o else "", "team": o[2]["team"] if o else "", "elig": o[2]["elig"] if o else [],
                     "inj": o[2]["inj"] if o else "ACTIVE",
                     "our": [round(float(v), 2) for v in u] if u is not None else None,
                     "our_tot": round(float(u.sum()), 2) if u is not None else None, "pg": pg})
    for k, r in enumerate(sorted([r for r in rows if r["our"] is not None], key=lambda r: -r["our_tot"])):
        r["our_rank"] = k + 1
    for r in rows:
        r.setdefault("our_rank", None)
        r["d_rank"] = (r["yahoo_rank"] - r["our_rank"]) if r["our_rank"] else None
    rows.sort(key=lambda r: r["yahoo_rank"])
    both = [r for r in rows if r["d_rank"] is not None]
    rho = None
    if len(both) > 10:
        a = np.argsort(np.argsort([r["yahoo_rank"] for r in both]))
        b = np.argsort(np.argsort([r["our_rank"] for r in both]))
        rho = float(np.corrcoef(a, b)[0, 1])
    rater = {"cats": [J.LABEL[c] for c in J.CATS], "keys": list(J.CATS), "mode": mode, "label": label, "ts": ts, "n_ranked": len(rows),
             "n_ours": len(both), "rank_corr": rho, "rows": [{k: v for k, v in r.items() if k != "pg"} for r in rows]}
    byid = {r["id"]: r for r in rows}
    rost = {}
    for tid, t in teams.items():
        lst = []
        for rec in t["roster"]:
            d = byid.get(str(rec["id"]))
            if d is None:                                        # rostered but outside the scraped rank list
                pr = J.projection_for(rec["name"], proj)
                pg = _pg(J.consistent(J.r11(pr["r"]))) if pr is not None else None
                d = {"id": rec["id"], "name": rec["name"], "team": rec["team"], "inj": rec["inj"], "elig": rec["elig"], "yahoo_rank": None,
                     "our_rank": None, "pg": pg}
            else:
                d = {**d, "team": rec["team"], "elig": rec["elig"], "inj": rec["inj"]}
            lst.append(d)
        lst.sort(key=lambda d: (d.get("our_rank") is None, d.get("our_rank") or 0))
        rost[str(tid)] = [{k: d.get(k) for k in ("id", "name", "team", "inj", "elig", "pg", "yahoo_rank", "our_rank")} for d in lst]
    return rater, rost
