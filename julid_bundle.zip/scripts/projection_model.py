"""Walk-forward projection model: does a model that knows about age, regression to the mean,
team changes, prior team quality, vacated minutes and (separately) availability beat the
project's current recipe -- on seasons it has NEVER seen?

For every target season t (2013-14 .. 2025-26) the model is fit ONLY on rows from seasons < t,
then scored on t. Compared on the same candidate players (prev MPG >= 15 and prev GP >= 30):

  last_season     value from t-1 only
  recipe          the project's current blend: .45/.30/.15/.10 over t-1..t-4
  learned_blend   OLS on v(t-1..t-3), age, age^2, prev MPG, prev usage   (no context)
  learned_ctx     learned_blend + moved, prior-bottom, prior-contender, vacated share, net talent
  ctx_x_avail     learned_ctx rate  x  separately-modelled expected games-played %

Metrics (per target season, then averaged): rank correlation with realized per-game value,
average REALIZED season total (rate x games played) of the model's top 84 (= 6 rounds x 14
teams), and top-84 overlap with the true top 84. Paired t-stat across seasons vs `recipe`.

Also exposes fit_all()/predict helpers so apply_projection.py can reuse the fitted models.
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import research_patterns as RP  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = RP.ROOT
OUTD = RP.OUTD
RECIPE_W = [0.45, 0.30, 0.15, 0.10]
BASE = ["v1", "v2", "v3", "has_v2", "has_v3", "age", "age2", "min1", "usg1"]
CTX = ["moved", "prior_bottom", "prior_contender", "vacated_share", "net_talent"]
GPF = ["gp1", "gp2", "gp3", "age", "min1", "value1", "prior_bottom", "moved", "si_era"]


def build_frame(P):
    """One row per (player, target season t) with features from seasons < t."""
    L = RP.link_prev(P)
    RF = RP.roster_features(P)
    L = L.merge(RF, on=["TEAM_ID", "si"], how="left")
    pv = P.pivot_table(index="PLAYER_ID", columns="si", values="value")
    pg = P.pivot_table(index="PLAYER_ID", columns="si", values="gp_pct")
    F = L.copy()
    for k in (1, 2, 3, 4):
        F[f"v{k}_raw"] = [pv.at[pid, si - k] if (si - k) in pv.columns and pid in pv.index else np.nan
                          for pid, si in zip(F["PLAYER_ID"], F["si"])]
        F[f"gp{k}_raw"] = [pg.at[pid, si - k] if (si - k) in pg.columns and pid in pg.index else np.nan
                           for pid, si in zip(F["PLAYER_ID"], F["si"])]
    return F


def featurize(F):
    X = pd.DataFrame(index=F.index)
    X["v1"] = F["v1_raw"]
    X["has_v2"] = F["v2_raw"].notna().astype(float)
    X["has_v3"] = F["v3_raw"].notna().astype(float)
    X["v2"] = F["v2_raw"].fillna(F["v1_raw"])
    X["v3"] = F["v3_raw"].fillna(X["v2"])
    X["age"] = F["p_AGE"]
    X["age2"] = (F["p_AGE"] - 27) ** 2
    X["min1"] = F["p_MIN"]
    X["usg1"] = F["p_usg"]
    X["moved"] = (F["p_TEAM_ID"] != F["TEAM_ID"]).astype(float)
    X["prior_bottom"] = (F["p_tier"] == "bottom").astype(float)
    X["prior_contender"] = (F["p_tier"] == "contender").astype(float)
    X["vacated_share"] = F["vacated_share"].fillna(F["vacated_share"].median())
    X["net_talent"] = (F["in_talent"] - F["out_talent"]).fillna(0)
    X["gp1"] = F["gp1_raw"]
    X["gp2"] = F["gp2_raw"].fillna(F["gp1_raw"])
    X["gp3"] = F["gp3_raw"].fillna(X["gp2"])
    X["value1"] = F["v1_raw"]
    X["si_era"] = F["si"].astype(float)
    return X


def recipe_pred(F):
    num = np.zeros(len(F)); den = np.zeros(len(F))
    for k, w in enumerate(RECIPE_W, start=1):
        v = F[f"v{k}_raw"].to_numpy(dtype=float)
        ok = ~np.isnan(v)
        num += np.where(ok, v * w, 0); den += np.where(ok, w, 0)
    return num / np.where(den == 0, np.nan, den)


def fit(Xtr, ytr, cols, ridge=1e-3):
    A = np.column_stack([np.ones(len(Xtr))] + [Xtr[c].to_numpy(dtype=float) for c in cols])
    mu = A.mean(axis=0); sd = A.std(axis=0); mu[0], sd[0] = 0, 1
    An = (A - mu) / sd
    pen = np.eye(A.shape[1]) * ridge; pen[0, 0] = 0
    beta = np.linalg.solve(An.T @ An + pen * len(An), An.T @ ytr)
    return {"cols": cols, "beta": beta, "mu": mu, "sd": sd}


def predict(model, X):
    A = np.column_stack([np.ones(len(X))] + [X[c].to_numpy(dtype=float) for c in model["cols"]])
    return ((A - model["mu"]) / model["sd"]) @ model["beta"]


def coef_table(model):
    b = model["beta"] / model["sd"]            # back to raw units
    return dict(zip(["const"] + model["cols"], map(float, b)))


def main():
    P, T = RP.load_all()
    F = build_frame(P)
    F = F[(F["p_MIN"] >= 15) & (F["p_GP"] >= 30)].copy()
    X = featurize(F)
    y = F["value"].to_numpy(); gp = F["gp_pct"].to_numpy(); total = y * gp
    ok = X[BASE + CTX + GPF].notna().all(axis=1).to_numpy() & ~np.isnan(recipe_pred(F)) & ~np.isnan(y)
    F, X, y, gp, total = F[ok], X[ok], y[ok], gp[ok], total[ok]
    si = F["si"].to_numpy()
    print(f"rows {len(F)}; target seasons {sorted(set(si))[0]}..{sorted(set(si))[-1]}")

    rows = []
    for t in range(9, 21):                       # 2014-15 .. 2025-26 as holdout targets
        tr, te = si < t, si == t
        if te.sum() < 100:
            continue
        m_blend = fit(X[tr], y[tr], BASE)
        m_ctx = fit(X[tr], y[tr], BASE + CTX)
        m_gp = fit(X[tr], gp[tr], GPF)
        xt = X[te]
        preds = {
            "last_season": xt["v1"].to_numpy(),
            "recipe": recipe_pred(F[te]),
            "learned_blend": predict(m_blend, xt),
            "learned_ctx": predict(m_ctx, xt),
        }
        gp_hat = np.clip(predict(m_gp, xt), 0.35, 0.98)
        preds["ctx_x_avail"] = preds["learned_ctx"] * gp_hat
        # the realized yardstick for "what did drafting this player deliver"
        for name, p in preds.items():
            k = 84
            pick = np.argsort(-p)[:k]
            best = np.argsort(-total[te])[:k]
            rows.append({
                "season": RP.SEASONS[t], "method": name,
                "spearman_rate": pd.Series(p).rank().corr(pd.Series(y[te]).rank()),
                "spearman_total": pd.Series(p).rank().corr(pd.Series(total[te]).rank()),
                "top84_realized_total": total[te][pick].mean(),
                "top84_overlap": len(set(pick) & set(best)) / k,
                "mae_rate": np.abs(p - y[te]).mean() if name != "ctx_x_avail" else np.nan,
            })
    R = pd.DataFrame(rows)
    R.to_csv(OUTD / "projection_backtest.csv", index=False)
    order = ["last_season", "recipe", "learned_blend", "learned_ctx", "ctx_x_avail"]
    S = R.groupby("method")[["spearman_rate", "spearman_total", "top84_realized_total", "top84_overlap", "mae_rate"]].mean().loc[order].round(3)
    print(f"\nWalk-forward, {R['season'].nunique()} holdout seasons:\n" + S.to_string())

    print("\nPaired difference vs `recipe` across seasons (mean, t, seasons better):")
    base = R[R["method"] == "recipe"].set_index("season")
    for name in order:
        if name == "recipe":
            continue
        cur = R[R["method"] == name].set_index("season")
        for metric in ("top84_realized_total", "spearman_total"):
            d = (cur[metric] - base[metric]).dropna()
            t = d.mean() / (d.std(ddof=1) / np.sqrt(len(d))) if d.std(ddof=1) > 0 else np.nan
            print(f"  {name:14s} {metric:22s} diff {d.mean():+.4f}  t={t:+.2f}  better in {(d > 0).sum()}/{len(d)}")

    # fit on everything for the coefficient report
    m_ctx = fit(X, y, BASE + CTX)
    m_gp = fit(X, gp, GPF)
    coefs = {"value_model": coef_table(m_ctx), "gp_model": coef_table(m_gp)}
    (OUTD / "projection_coefficients.json").write_text(json.dumps(coefs, indent=1))
    print("\nFull-sample value-model coefficients (raw units):")
    for k, v in coefs["value_model"].items():
        print(f"  {k:16s} {v:+.3f}")
    print("\nGP%-model coefficients:")
    for k, v in coefs["gp_model"].items():
        print(f"  {k:16s} {v:+.3f}")


if __name__ == "__main__":
    main()
