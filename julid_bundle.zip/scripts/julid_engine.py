"""9-category engine for the Yahoo "Julid NBA League" (id 17676), ported from the ESPN Lapis engine (inseason_live.py).

League: 12 teams, H2H Categories, 9 cats FG% FT% 3PTM PTS REB AST STL BLK TO (turnovers lower-is-better), each cat W/L/T,
matchup won with >= 5 of 9. Roster slots PG SG G SF PF F C C Util Util + 3 BN (+2 IL). NO games cap, daily lineups, 100 adds for the
whole season (no weekly limit), waivers 1 day. Weeks: wk1 Tue Oct 20-Sun Oct 25, then Mon-Sun; wk7 (Nov 30-Dec 13) and wk17
(Feb 15-28) are two-week matchups; wk22 ends Apr 4.

Shared with the ESPN engine (imported from inseason_live): projections (raw per-game stats from the pool z-scores, blended with real
games), play probabilities, return dates, teammate-absence boost, the NBA schedule. New here: 9-cat maths, Yahoo slot rules, a daily
lineup solver without a cap (best 10 every day), P(win) = P(>= 5 of 9), the add budget (100/season) and the league power table.

Known limits: opponent lineups are assumed optimal; categories are treated as independent (the ESPN backtest found the matchup % a bit too
extreme -> `calib_win`, slope not re-fit for 9 cats yet); free agents are approximated by every pool player not rostered in the league
until the Yahoo free-agent list is read; P(play) is a flat 0.90 for healthy players until games exist.
"""
import json
import os
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_live as L  # noqa: E402
import inseason_schedule as SCH  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = G.ROOT
# Yahoo snapshots (rosters.psv, free_agents.psv, matchup_live.json): local default D:\JH\NBA\julid\data\raw, the cloud build sets JULID_RAW
RAW_DIR = Path(os.environ.get("JULID_RAW") or (ROOT.parent.parent / "julid" / "data" / "raw"))
LEAGUE_ID = 17676
MY_TEAM = 9                                   # "Sigma Team"
SEASON_START = date(2026, 10, 20)
SEASON_ADDS = 100
CATS = ["fg_pct", "ft_pct", "3pm", "pts", "reb", "ast", "stl", "blk", "to"]
LABEL = {"fg_pct": "FG%", "ft_pct": "FT%", "3pm": "3PM", "pts": "PTS", "reb": "REB", "ast": "AST", "stl": "STL", "blk": "BLK", "to": "TO"}
LOWER_BETTER = {"to"}
WIN_NEED = 5
# raw component vector R (11): per-game makes/attempts and counting stats
COMP = ["fgm", "fga", "ftm", "fta", "3pm", "pts", "reb", "ast", "stl", "blk", "to"]
CI = {c: i for i, c in enumerate(COMP)}
PCT = {"fg_pct": ("fgm", "fga"), "ft_pct": ("ftm", "fta")}
SLOTS = ["PG", "SG", "G", "SF", "PF", "F", "C", "C", "UTIL", "UTIL"]
SLOT_OK = {"PG": {"PG"}, "SG": {"SG"}, "G": {"PG", "SG"}, "SF": {"SF"}, "PF": {"PF"}, "F": {"SF", "PF"}, "C": {"C"}}
G_AVG = L.G_AVG
WIN_SHRINK = 1.0                              # ESPN 13-cat backtest slope was 0.906; not re-fit for 9 cats yet (see research notes)

# Yahoo calendar (read from the league's matchup pages 2026-10-14)
WEEKS = {1: (date(2026, 10, 20), date(2026, 10, 25)), 2: (date(2026, 10, 26), date(2026, 11, 1))}
for _w in range(3, 23):
    _s = date(2026, 11, 2) + timedelta(days=7 * (_w - 3))
    WEEKS[_w] = (_s, _s + timedelta(days=6))
WEEKS[7] = (date(2026, 11, 30), date(2026, 12, 13))                 # two-week matchup
for _w in range(8, 18):
    _s = date(2026, 12, 14) + timedelta(days=7 * (_w - 8))
    WEEKS[_w] = (_s, _s + timedelta(days=6))
WEEKS[17] = (date(2027, 2, 15), date(2027, 2, 28))                  # All-Star two-week matchup
for _w in range(18, 23):
    _s = date(2027, 3, 1) + timedelta(days=7 * (_w - 18))
    WEEKS[_w] = (_s, _s + timedelta(days=6))
# Sigma Team's opponent (Yahoo team id) per week, read from the league's matchup pages 2026-10-14. Weeks 20-22 = playoffs (set by standings).
OPP_BY_WEEK = {1: 12, 2: 6, 3: 7, 4: 4, 5: 3, 6: 10, 7: 5, 8: 11, 9: 1, 10: 2, 11: 8, 12: 12, 13: 6, 14: 7, 15: 4, 16: 3, 17: 10, 18: 5, 19: 11}
INJ_MAP = {"P": "ACTIVE", "GTD": "DAY_TO_DAY", "DTD": "DAY_TO_DAY", "Q": "DAY_TO_DAY", "O": "OUT", "NA": "OUT", "SUSP": "OUT", "INJ": "OUT", "IL": "OUT"}
ALIASES = {"nalexanderwalker": "nickeilalexanderwalker"}


def period_of(d):
    for w, (a, b) in WEEKS.items():
        if a <= d <= b:
            return w
    return 22 if d > WEEKS[22][1] else 1


# ---------------------------------------------------------------- 9-cat constants
def _q_reb_sd():
    """sd of OREB+DREB inside the same draftable pool the ESPN engine uses (top Q_SIZE by 13-cat z-sum)."""
    import percat as PC
    pool = L.LAST[(L.LAST["GP"] >= 20) & (L.LAST["MIN"] >= 15)].copy()
    z1 = pd.DataFrame(index=pool.index)
    for c, col in PC.COUNT.items():
        z1[c] = (pool[col] - pool[col].mean()) / pool[col].std()
    for c, (a, b) in PC.PCT.items():
        comp = pool[a].sum() / pool[b].sum()
        imp = pool[a] - comp * pool[b]
        z1[c] = (imp - imp.mean()) / imp.std()
    z1[["to", "pf"]] *= -1
    Qp = pool.loc[z1.sum(axis=1).sort_values(ascending=False).head(PC.Q_SIZE).index]
    return float((Qp["OREB"] + Qp["DREB"]).std())


Q = L.Q
SD = {c: Q["sd"][c] for c in ("pts", "stl", "blk", "3pm", "ast", "to")}
SD["reb"] = _q_reb_sd()
COMPOSITE = {"fg_pct": Q["comp"]["fg_pct"], "ft_pct": Q["comp"]["ft_pct"]}
IMP_SD = {"fg_pct": Q["imp_sd"]["fg_pct"], "ft_pct": Q["imp_sd"]["ft_pct"]}
_c13 = {c: i for i, c in enumerate(G.CATS13)}


def _map13(arr13, reb="mean"):
    a = np.asarray(arr13, dtype=float)
    return np.array([a[_c13["fg_pct"]], a[_c13["ft_pct"]], a[_c13["3pm"]], a[_c13["pts"]], 0.5 * (a[_c13["oreb"]] + a[_c13["dreb"]]),
                     a[_c13["ast"]], a[_c13["stl"]], a[_c13["blk"]], a[_c13["to"]]])


TAU9 = _map13(G.TAU)                           # weekly noise per player in z units (REB = mean of OREB / DREB)
BAL9 = _map13(G.RATIO)                         # balanced category weights (G-score reliability ratios)


def r11(r14):
    """ESPN-engine 14-component vector (L.COMP order) -> 9-cat component vector (COMP order here)."""
    g = lambda c: r14[L.CI[c]]
    return np.array([g("fgm"), g("fga"), g("ftm"), g("fta"), g("3pm"), g("pts"), g("oreb") + g("dreb"), g("ast"), g("stl"), g("blk"), g("to")])


ABS_K9 = r11(L.ABS_K)
ABS_K9[CI["reb"]] = 0.5 * (L.ABS_K[L.CI["oreb"]] + L.ABS_K[L.CI["dreb"]])


FG_PRIOR, FG_REGRESS_ATT = 0.50, 300.0


def consistent(r):
    """Projection lines mix two sources: points / FTM / 3PM come from the validated pool z-scores (forward-looking: role, age) while shot
    volume (FGA) is last season's. For a player whose role grows or shrinks the two disagree (e.g. Lively II: 9.9 pts on 2.6 FGA = 83% FG).
    Points = 2*FGM + 3PM + FTM, so trust the projected points: FGM = (pts - ftm - 3pm)/2 (kept within 0.5x..1.8x of the old FGM so one
    odd z-score cannot dominate), FG% = his old rate regressed toward 50% by his attempts (~40 games), FGA = FGM / FG%."""
    r = r.copy()
    fgm0, fga0 = r[CI["fgm"]], r[CI["fga"]]
    if fga0 <= 0 or fgm0 <= 0:
        return r
    implied = (r[CI["pts"]] - r[CI["ftm"]] - r[CI["3pm"]]) / 2.0
    fgm = float(np.clip(implied, 0.5 * fgm0, 1.8 * fgm0))
    w = (fga0 * 40.0) / (fga0 * 40.0 + FG_REGRESS_ATT)
    fgp = float(np.clip(w * (fgm0 / fga0) + (1 - w) * FG_PRIOR, 0.38, 0.66))
    r[CI["fgm"]], r[CI["fga"]] = fgm, fgm / fgp
    return r


def sigma_units(r):
    """One started game in sigma units for the 9 cats (TO negative; % cats = made - league-rate*attempts, over its sd)."""
    u = np.zeros(9)
    for i, c in enumerate(CATS):
        if c in PCT:
            a, b = PCT[c]
            u[i] = (r[CI[a]] - COMPOSITE[c] * r[CI[b]]) / IMP_SD[c]
        else:
            u[i] = (-1 if c in LOWER_BETTER else 1) * r[CI[c]] / SD[c]
    return u


# ---------------------------------------------------------------- players
def _elig(pos):
    return {p for p in str(pos).replace("/", ",").split(",") if p in ("PG", "SG", "SF", "PF", "C")} or {"PG", "SG", "SF", "PF", "C"}


def load_rosters(path=None):
    path = path or RAW_DIR / "rosters.psv"
    teams = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        tid, team, pid, name, slot, tp, status = (line.split("|") + [""])[:7]
        nba, pos = tp.split("-", 1)
        t = teams.setdefault(int(tid), {"id": int(tid), "name": team, "roster": []})
        t["roster"].append({"id": pid, "name": name, "team": L.tri(nba), "elig": sorted(_elig(pos)), "slot": slot,
                            "inj": INJ_MAP.get(status, "ACTIVE"), "yahoo_status": status})
    return teams


def projection_for(name, proj):
    k = L.norm(name)
    k = ALIASES.get(k, k)
    return proj.get(k) or L.fallback_projection(name) or L.fallback_projection(name.replace("N. ", "Nickeil "))


def mk_player(rec, pr):
    r = consistent(r11(pr["r"]))
    base = L._AVAIL.get(L.norm(rec["name"]))
    return {"name": rec["name"], "team": rec["team"], "elig": set(rec["elig"]), "inj": rec.get("inj", "ACTIVE"), "ret": rec.get("ret"),
            "base": base, "p": L.p_play(rec.get("inj"), 0, base), "r": r, "u": sigma_units(r), "src": pr["src"], "id": rec.get("id"),
            "slot": rec.get("slot"), "own": rec.get("own")}


def default_player(rec):
    """No projection (e.g. a rookie without games): replacement-level line so the roster still counts."""
    r = np.array([2.6, 6.0, 1.0, 1.4, 0.8, 7.0, 3.0, 1.5, 0.5, 0.3, 1.0])
    return mk_player(rec, {"r": np.zeros(14), "src": "no projection (replacement level)"}) | {"r": r, "u": sigma_units(r)}


def build_players(recs, proj, warnings):
    out = []
    for rec in recs:
        pr = projection_for(rec["name"], proj)
        if pr is None:
            warnings.append(f"no projection for {rec['name']}: replacement-level line used")
            out.append(default_player(rec))
        else:
            out.append(mk_player(rec, pr))
    return out


# ---------------------------------------------------------------- lineup solver
def _slots_for(el):
    return [s for s, name in enumerate(SLOTS) if name == "UTIL" or SLOT_OK[name] & el]


def _assign(elig_list):
    """Augmenting-path matching of players (elig sets) to the 10 slots. Returns {slot: player position in list} or None if infeasible."""
    match = {}

    def aug(i, seen):
        for s in _slots_for(elig_list[i]):
            if s in seen:
                continue
            seen.add(s)
            if s not in match or aug(match[s], seen):
                match[s] = i
                return True
        return False

    for i in range(len(elig_list)):
        if not aug(i, set()):
            return None
    return match


def day_lineup(cands):
    """Best set of starters for one day. cands: list of (idx, elig, value). Feasible lineups form a transversal matroid, so adding players
    by descending value whenever a legal slot assignment still exists is exactly optimal. An empty slot is worth 0: players with value <= 0
    stay on the bench. Returns {slot_index: idx}."""
    chosen, elig = [], []
    for c in sorted(cands, key=lambda c: -c[2]):
        if c[2] <= 0:
            break
        if _assign(elig + [c[1]]) is not None:
            chosen.append(c)
            elig.append(c[1])
    m = _assign(elig) or {}
    return {s: chosen[i][0] for s, i in m.items()}


class Week:
    def __init__(self, w, real_today=None, now_utc=None):
        self.w = w
        self.start, self.end = WEEKS[w]
        self.n = (self.end - self.start).days + 1
        self.real_today = real_today or date.today()
        now_utc = now_utc or datetime.now(timezone.utc).replace(tzinfo=None)
        self.today_idx = 0 if self.real_today <= self.start else min(self.n, (self.real_today - self.start).days)
        sch = SCH.games()
        sch = sch[(sch["date"].dt.date >= self.start) & (sch["date"].dt.date <= self.end)].copy()
        sch["idx"] = (sch["date"].dt.date - self.start).map(lambda x: x.days)
        sch["started"] = sch["tip_utc"] <= pd.Timestamp(now_utc)
        self.sch = sch
        self.finished = self.real_today > self.end

    def play_days(self):
        """team -> set of day idx whose game has not tipped yet (today's started games are in the actual totals)."""
        o = {}
        for r in self.sch.itertuples():
            if r.idx < self.today_idx or (r.idx == self.today_idx and r.started):
                continue
            o.setdefault(r.team, set()).add(int(r.idx))
        return o


def team_pack(players, wk, weights, actual=None):
    """Plan the best lineup for every remaining day and total up expected stats and variance."""
    pdays = wk.play_days()
    starts, grid = [], {}
    for d in range(wk.today_idx, wk.n):
        day = wk.start + timedelta(days=d)
        cands = []
        for i, p in enumerate(players):
            if d not in pdays.get(p["team"], ()):
                continue
            pp = L.day_p(p["inj"], p.get("ret"), p.get("base"), day, wk.real_today)
            if pp <= 0:
                continue
            m, _ = L.absence_m(p["team"], L.norm(p["name"]), day, wk.real_today)
            mult = 1.0 + ABS_K9 * m if m > 0.01 else None
            r = p["r"] * mult if mult is not None else p["r"]
            v = float((sigma_units(r) if mult is not None else p["u"]) @ weights) / G_AVG * pp
            cands.append((i, p["elig"], v, pp, r))
        sel = day_lineup([(c[0], c[1], c[2]) for c in cands])
        by = {c[0]: c for c in cands}
        for s, i in sel.items():
            starts.append((i, d, by[i][3], by[i][4], SLOTS[s]))
            grid.setdefault(players[i]["name"], {})[d] = (round(by[i][3], 2), SLOTS[s])
    return {"starts": starts, "grid": grid, "players": players, "actual": actual, "weights": weights}


def aggregate(pack, upto=None):
    tot, var = np.zeros(11), np.zeros(9)
    act = pack.get("actual")
    if act:
        tot += np.array([act.get(c, 0.0) for c in COMP], dtype=float)
    for i, d, p, r, _ in pack["starts"]:
        if upto is not None and d > upto:
            continue
        tot += p * r
        for j, c in enumerate(CATS):
            if c in PCT:
                a, b = PCT[c]
                x, base = r[CI[a]] - COMPOSITE[c] * r[CI[b]], IMP_SD[c]
            else:
                x, base = r[CI[c]], SD[c]
            var[j] += p * TAU9[j] ** 2 * G_AVG * base ** 2 + p * (1 - p) * x * x
    return tot, var


def cat_values(tot):
    return {c: (tot[CI[PCT[c][0]]] / tot[CI[PCT[c][1]]] if tot[CI[PCT[c][1]]] > 0 else 0.0) if c in PCT else tot[CI[c]] for c in CATS}


def evaluate(t1, v1, t2, v2):
    """P(win each category) for team 1, P(>= 5 of 9)."""
    pc = np.zeros(9)
    for j, c in enumerate(CATS):
        if c in PCT:
            a, b = PCT[c]
            a1, a2 = max(t1[CI[b]], 1e-9), max(t2[CI[b]], 1e-9)
            mean = t1[CI[a]] / a1 - t2[CI[a]] / a2
            sd = np.sqrt(v1[j] / a1 ** 2 + v2[j] / a2 ** 2)
        else:
            mean, sd = t1[CI[c]] - t2[CI[c]], np.sqrt(v1[j] + v2[j])
        if c in LOWER_BETTER:
            mean = -mean
        pc[j] = float(G.cdf(mean / sd)) if sd > 1e-9 else (1.0 if mean > 1e-9 else (0.0 if mean < -1e-9 else 0.5))
    return pc, p_at_least(pc, WIN_NEED)


def p_at_least(pc, k):
    dp = np.zeros(len(pc) + 1)
    dp[0] = 1.0
    for p in pc:
        nxt = dp * (1 - p)
        nxt[1:] += dp[:-1] * p
        dp = nxt
    return float(dp[k:].sum())


def calib_win(p, a=WIN_SHRINK):
    p = float(np.clip(p, 1e-4, 1 - 1e-4))
    return float(1 / (1 + np.exp(-a * np.log(p / (1 - p)))))


def matchup(pk1, pk2, upto=None):
    t1, v1 = aggregate(pk1, upto)
    t2, v2 = aggregate(pk2, upto)
    pc, pw = evaluate(t1, v1, t2, v2)
    return pc, pw, t1, t2


def optimise_weights(players, opp_pack, wk, base_w=BAL9, passes=2, actual=None):
    """Coordinate search over category weights (punt / push) that raises my P(win) against this opponent: each weight tried at 100/50/0%."""
    w = base_w.copy()
    best_pk = team_pack(players, wk, w, actual)
    best = matchup(best_pk, opp_pack)[1]
    for _ in range(passes):
        changed = False
        for i in range(9):
            for lv in (1.0, 0.5, 0.0):
                t = w.copy()
                t[i] = base_w[i] * lv
                if np.allclose(t, w):
                    continue
                pk = team_pack(players, wk, t, actual)
                pw = matchup(pk, opp_pack)[1]
                if pw > best + 1e-4:
                    best, w, best_pk, changed = pw, t, pk, True
        if not changed:
            break
    return w, best_pk, best


# ---------------------------------------------------------------- streaming (budget aware)
def add_budget(adds_used, week):
    """100 adds for the season: how many are 'fair share' by now. Returns dict used / left / weeks left / per-week pace."""
    weeks_left = 22 - week + 1
    left = SEASON_ADDS - adds_used
    return {"used": adds_used, "left": left, "weeks_left": weeks_left, "per_week": round(left / max(weeks_left, 1), 2)}


def long_value(p, weights=BAL9):
    """Season-long worth of a player: value per game (sigma units x weights / G_AVG) x chance he plays when healthy x chance he is not out."""
    avail = (p.get("base") or L.P_ACTIVE) * (0.5 if p["inj"] == "OUT" else 1.0)
    return float(p["u"] @ weights) / G_AVG * avail


FA_DISCOUNT, LONG_TOL = 0.85, 0.30        # free-agent values are shaded 15% (winner's curse: the best-looking pool players are overrated); an add must be within 0.30 of the drop


def streaming(players, opp_pack, wk, weights, fa, base_pw, base_pc, k_drop=3, k_fa=60, actual=None):
    """Best add/drop swaps for the rest of the week, ranked by change in P(win)."""
    if wk.finished:
        return []
    pdays = wk.play_days()
    # Drop candidates = the players who matter least over the SEASON (value per game x how often he plays), not the ones with the fewest
    # games this week: a good player with a light schedule (2 games) is not a drop, he plays more next week and costs an add to get back.
    drops = sorted(players, key=lambda p: long_value(p, weights))[:k_drop]
    cand = []
    for f in fa:
        left = len(pdays.get(f["team"], ()))
        if f["p"] > 0 and left:
            cand.append((float(f["u"] @ weights) * f["p"] * left, f))
    cand = [f for _, f in sorted(cand, key=lambda x: -x[0])[:k_fa]]
    rows = []
    for f in cand:
        for d in drops:
            if long_value(f, weights) * FA_DISCOUNT < long_value(d, weights) - LONG_TOL:
                continue                                     # a real downgrade for the rest of the season, not just a one-week stream
            roster = [q for q in players if q is not d] + [f]
            pc, pw, t1, _ = matchup(team_pack(roster, wk, weights, actual), opp_pack)
            eff = [(LABEL[c], float(pc[j] - base_pc[j])) for j, c in enumerate(CATS)]
            rows.append({"add": f["name"], "add_team": f["team"], "drop": d["name"], "drop_value": round(long_value(d, weights), 2),
                         "add_value": round(long_value(f, weights), 2), "d_pwin": pw - base_pw, "pwin": pw,
                         "d_cats": float(pc.sum() - base_pc.sum()), "games": len(pdays.get(f["team"], ())),
                         "helps": [e for e in sorted(eff, key=lambda e: -e[1]) if e[1] >= 0.01],
                         "hurts": [e for e in sorted(eff, key=lambda e: e[1]) if e[1] <= -0.01]})
    rows.sort(key=lambda x: -(x["d_pwin"] + 0.02 * x["d_cats"]))
    return rows


# ---------------------------------------------------------------- league
def league_power(teams_pl, wk, weights=BAL9):
    """Every team's expected 9-cat totals this week; all-play expected categories won vs the other 11 (a luck-free strength measure)."""
    packs = {tid: team_pack(pl, wk, weights) for tid, pl in teams_pl.items()}
    ids = list(packs)
    tv = {t: aggregate(packs[t]) for t in ids}
    out = {}
    for a in ids:
        cats, wins = 0.0, 0.0
        for b in ids:
            if a == b:
                continue
            pc, pw = evaluate(*tv[a], *tv[b])
            cats += pc.sum()
            wins += pw
        out[a] = {"exp_cats_vs_avg": cats / (len(ids) - 1), "p_win_vs_avg": wins / (len(ids) - 1),
                  "cat_p": {LABEL[c]: float(np.mean([evaluate(*tv[a], *tv[b])[0][j] for b in ids if b != a])) for j, c in enumerate(CATS)}}
    return out, packs


# ---------------------------------------------------------------- state
FA_FILE = RAW_DIR / "free_agents.psv"


def load_free_agents(rostered_keys, proj, limit=300, path=None):
    """Yahoo's real free-agent list (top 200 by % owned, read from the league's Players page). Falls back to 'every pool player nobody
    rosters' if the file is missing. Players without a projection are skipped."""
    path = Path(path or FA_FILE)
    out = []
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            pid, name, info, own = (line.split("|") + ["", "", "", ""])[:4]
            toks = info.split(" ", 1)
            status = ""
            if toks[0] in INJ_MAP and len(toks) > 1:
                status, info = toks[0], toks[1]
            nba, pos = info.split(" - ", 1)
            k = L.norm(name)
            if ALIASES.get(k, k) in rostered_keys or projection_for(name, proj) is None:
                continue
            out.append({"id": pid, "name": name, "team": L.tri(nba.strip()), "elig": sorted(_elig(pos)),
                        "inj": INJ_MAP.get(status, "ACTIVE"),
                        "own": float(own.strip("%") or 0)})
        return out[:limit]
    pool = pd.read_csv(ROOT / "data" / "pool_2026-27_v31.csv").drop_duplicates("PLAYER_NAME")
    for _, row in pool.iterrows():
        k = L.norm(row["PLAYER_NAME"])
        if k in rostered_keys or k not in proj:
            continue
        out.append({"name": row["PLAYER_NAME"], "team": L.tri(str(row["team_2026_27"])), "elig": sorted(_elig(row["eligible_slots"])),
                    "inj": "ACTIVE", "own": None})
    return out[:limit]


LIVE_FILE = RAW_DIR / "matchup_live.json"


def load_actual(week, me_name, opp_name, path=None):
    """Live matchup totals scraped from Yahoo (matchup_live.json: {week, teams: {team name: {fgm, fga, ftm, fta, 3pm, pts, reb, ast, stl, blk, to}}}).
    Returns (mine, theirs) component dicts, or (None, None) if missing / another week / nothing played yet."""
    path = Path(path or LIVE_FILE)
    try:
        j = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None, None
    if j.get("week") != week:
        return None, None
    t = j.get("teams", {})
    a, b = t.get(me_name), t.get(opp_name)
    if not a or not b or (sum(a.values()) + sum(b.values())) <= 0:
        return None, None
    return {c: float(a.get(c, 0.0)) for c in COMP}, {c: float(b.get(c, 0.0)) for c in COMP}


def build_state(week=None, opp_id=None, today=None, adds_used=0, with_streaming=True, teams=None):
    today = today or date.today()
    w = week or period_of(max(today, SEASON_START))
    wk = Week(w, real_today=today)
    warnings = []
    proj = L.load_projections()
    try:
        import espn_site as ES
        feed = ES.injuries()
    except Exception as ex:
        feed = {}
        warnings.append(f"injury feed unavailable ({type(ex).__name__})")
    L.set_absences(feed)
    teams = teams or load_rosters()
    gpt = wk.sch.groupby("team").size()
    if len(gpt) and gpt.mean() < 0.45 * wk.n:
        warnings.append(f"week {w}: only {gpt.mean():.1f} games per team are published so far (NBA Cup games are added in December); "
                        "projections for this week are understated")
    for t in teams.values():
        L.enrich_injuries(t["roster"], feed)
    pl = {tid: build_players(t["roster"], proj, warnings) for tid, t in teams.items()}
    opp_id = opp_id or OPP_BY_WEEK.get(w)
    if opp_id is None:                                      # playoff weeks: the opponent is not known until the standings settle
        rk, _ = league_power(pl, wk)
        return {"week": w, "start": wk.start.isoformat(), "end": wk.end.isoformat(), "me": teams[MY_TEAM]["name"], "opp": None,
                "warnings": warnings + [f"week {w}: opponent not set yet (playoffs); pass opp_id=<team id> to project a specific matchup"],
                "power": sorted([{"id": t, "team": teams[t]["name"], **v} for t, v in rk.items()], key=lambda x: -x["exp_cats_vs_avg"])}
    me, opp = pl[MY_TEAM], pl[opp_id]
    act_me, act_opp = load_actual(w, teams[MY_TEAM]["name"], teams[opp_id]["name"])
    opp_pack = team_pack(opp, wk, BAL9, act_opp)
    wts, pk_me, _ = optimise_weights(me, opp_pack, wk, actual=act_me)
    pc, pw, t1, t2 = matchup(pk_me, opp_pack)
    cv1, cv2 = cat_values(t1), cat_values(t2)
    n1 = cat_values(np.array([act_me[c] for c in COMP])) if act_me else None
    n2 = cat_values(np.array([act_opp[c] for c in COMP])) if act_opp else None
    cats = [{"key": c, "label": LABEL[c], "me": cv1[c], "opp": cv2[c], "p": float(pc[j]),
             "me_now": n1[c] if n1 else None, "opp_now": n2[c] if n2 else None, "weight": float(wts[j] / BAL9[j]),
             "tag": "lock" if pc[j] >= .8 else "lean" if pc[j] >= .6 else "toss-up" if pc[j] > .4 else "lean opp" if pc[j] > .2 else "concede"}
            for j, c in enumerate(CATS)]
    days = [(wk.start + timedelta(days=i)).strftime("%a %m/%d") for i in range(wk.n)]
    state = {"week": w, "start": wk.start.isoformat(), "end": wk.end.isoformat(), "days": days, "me": teams[MY_TEAM]["name"],
             "opp": teams[opp_id]["name"], "p_win": calib_win(pw), "p_win_raw": pw, "exp_cats": float(pc.sum()), "cats": cats,
             "grid": pk_me["grid"], "budget": add_budget(adds_used, w), "warnings": warnings, "has_actual": bool(act_me)}
    state["asof"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    state["lineup"] = lineup_view(pk_me, wk, me)
    state["roster"] = roster_view(me, pk_me, wk)
    state["opp_roster"] = roster_view(opp, opp_pack, wk)
    if act_me is None and wk.today_idx > 0:
        warnings.append("no live totals for this week yet (matchup_live.json missing or stale): projections ignore what already happened")
    state["outlook"] = season_outlook(pl, today, w)
    for o in state["outlook"]:
        o["p_win"], o["opp"] = calib_win(o["p_win"]), teams[o["opp_id"]]["name"]
    state["teams"] = {str(t): {"name": v["name"], "players": [r["name"] for r in v["roster"]]} for t, v in teams.items()}
    state["calib"] = {"win_shrink": WIN_SHRINK}
    try:                                                     # Yahoo player ranks vs ours, per-team roster analysis (julid_rater.py)
        import julid_rater as JR
        state["rater"], state["rosters"] = JR.build(teams, proj, today, warnings)
    except Exception as ex:
        import traceback
        traceback.print_exc()
        state["rater"], state["rosters"] = None, None
        warnings.append(f"player rater unavailable ({type(ex).__name__}: {str(ex)[:80]})")
    try:
        state["moves_log"] = json.loads((RAW_DIR / "moves_log.json").read_text(encoding="utf-8"))[:40]
    except Exception:
        state["moves_log"] = []
    rk, _ = league_power(pl, wk)
    state["power"] = sorted([{"id": t, "team": teams[t]["name"], **v} for t, v in rk.items()], key=lambda x: -x["exp_cats_vs_avg"])
    if with_streaming:
        rost = {ALIASES.get(L.norm(r["name"]), L.norm(r["name"])) for t in teams.values() for r in t["roster"]}
        recs = load_free_agents(rost, proj)
        L.enrich_injuries(recs, feed)                       # return dates and the newest note for free agents too
        fa = build_players(recs, proj, warnings)
        rows = streaming(me, opp_pack, wk, wts, fa, pw, pc, actual=act_me)
        state["streaming"] = rows[:12]
        state["fa"] = {"rows": [], "near": [], "near_rows": [], "thresholds": {}, "mine": [], "n_pool": 0}
        state["trades"] = {"rows": []}
        try:                                                # free-agent tiers + breakout radar (julid_fa.py) and the trade finder (julid_trade.py)
            import julid_fa as JF
            me_pow = next(r for r in state["power"] if r["id"] == MY_TEAM)
            state["fa"] = JF.fa_block(me, fa, wk, rows, me_pow, today, state["budget"]["left"])
        except Exception as ex:
            import traceback
            traceback.print_exc()
            warnings.append(f"free-agent list unavailable ({type(ex).__name__}: {str(ex)[:80]})")
        try:
            import time as _t
            import julid_trade as JT
            t0 = _t.time()
            state["trades"] = JT.find_trades(teams, pl, w, today, MY_TEAM, state["power"], fa)
            state["trades"]["seconds"] = round(_t.time() - t0, 1)
            try:
                state["trades"]["by_partner"] = JT.partner_trades(teams, pl, w, today, MY_TEAM, state["power"], fa)
            except Exception as ex2:
                import traceback
                traceback.print_exc()
                warnings.append(f"partner trades unavailable ({type(ex2).__name__}: {str(ex2)[:80]})")
        except Exception as ex:
            import traceback
            traceback.print_exc()
            warnings.append(f"trade finder unavailable ({type(ex).__name__}: {str(ex)[:80]})")
    return state


def _line(r):
    return {"pts": round(float(r[CI["pts"]]), 1), "reb": round(float(r[CI["reb"]]), 1), "ast": round(float(r[CI["ast"]]), 1),
            "stl": round(float(r[CI["stl"]]), 1), "blk": round(float(r[CI["blk"]]), 1), "tpm": round(float(r[CI["3pm"]]), 1),
            "to": round(float(r[CI["to"]]), 1), "fg": round(float(r[CI["fgm"]] / r[CI["fga"]]), 3) if r[CI["fga"]] else 0.0,
            "ft": round(float(r[CI["ftm"]] / r[CI["fta"]]), 3) if r[CI["fta"]] else 0.0}


def lineup_view(pk, wk, players):
    """Per remaining day: who starts in which slot (with chance he plays), who sits although he has a game, who has no game."""
    pdays = wk.play_days()
    days = []
    for d in range(wk.n):
        day = wk.start + timedelta(days=d)
        st = {i: (p, s) for i, dd, p, _r, s in pk["starts"] if dd == d}
        row = {"day": day.strftime("%a %m/%d"), "idx": d, "past": d < wk.today_idx,
               "starters": sorted([{"slot": s, "name": players[i]["name"], "team": players[i]["team"], "p": round(p, 2)} for i, (p, s) in st.items()],
                                  key=lambda x: SLOTS.index(x["slot"]) if x["slot"] in SLOTS else 99),
               "bench": [], "off": []}
        for i, pl in enumerate(players):
            if i in st:
                continue
            has = d in pdays.get(pl["team"], ()) if d >= wk.today_idx else False
            (row["bench"] if has else row["off"]).append(pl["name"])
        days.append(row)
    return days


def roster_view(players, pk, wk):
    pdays = wk.play_days()
    n_start = {}
    for i, d, *_ in pk["starts"]:
        n_start[i] = n_start.get(i, 0) + 1
    return [{"name": p["name"], "team": p["team"], "pos": "/".join(x for x in POS5 if x in p["elig"]), "inj": p["inj"],
             "games": len(pdays.get(p["team"], ())), "starts": n_start.get(i, 0), "line": _line(p["r"]), "src": p["src"]}
            for i, p in enumerate(players)]


POS5 = ["PG", "SG", "SF", "PF", "C"]


def season_outlook(pl, today, from_week, opp_by_week=None):
    """P(win) and expected categories for every remaining regular-season week against the scheduled opponent (balanced weights)."""
    out = []
    for w in range(from_week, 20):
        opp = (opp_by_week or OPP_BY_WEEK).get(w)
        wk = Week(w, real_today=today)
        pc, pw, t1, t2 = matchup(team_pack(pl[MY_TEAM], wk, BAL9), team_pack(pl[opp], wk, BAL9))
        gpt = wk.sch.groupby("team").size()
        out.append({"week": w, "start": wk.start.isoformat(), "end": wk.end.isoformat(), "opp_id": opp, "p_win": float(pw), "exp_cats": float(pc.sum()),
                    "partial_schedule": bool(len(gpt) and gpt.mean() < 0.45 * wk.n)})
    return out


def report(s):
    L_ = [f"Week {s['week']} ({s['start']} - {s['end']}): {s['me']} vs {s['opp']}",
          f"  P(win) {s['p_win']*100:.0f}%   expected cats {s['exp_cats']:.2f} / 9   (need 5)",
          "  cat    me        opp       P(win)  weight  call"]
    for c in s["cats"]:
        f = (lambda v: f"{v:.3f}") if c["key"] in PCT else (lambda v: f"{v:.1f}")
        L_.append(f"  {c['label']:<5} {f(c['me']):>8} {f(c['opp']):>9} {c['p']*100:>7.0f}% {c['weight']:>6.1f}  {c['tag']}")
    b = s["budget"]
    L_.append(f"  adds: {b['used']} used, {b['left']} left of {SEASON_ADDS}, {b['weeks_left']} weeks left (fair share {b['per_week']}/week)")
    L_.append("  power (expected cats vs an average opponent):")
    for i, t in enumerate(s["power"], 1):
        L_.append(f"   {i:>2}. {t['team'][:18]:<18} {t['exp_cats_vs_avg']:.2f}   P(win) {t['p_win_vs_avg']*100:.0f}%")
    for r in s.get("streaming", [])[:6]:
        L_.append(f"  add {r['add']} ({r['add_team']}, {r['games']}g) drop {r['drop']}: {r['d_pwin']*100:+.1f} pts, {r['d_cats']:+.2f} cats")
    for w_ in s["warnings"][:8]:
        L_.append("  ! " + w_)
    return "\n".join(L_)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    st = build_state(week=int(args[0]) if args else 1, today=date(2026, 10, 14), with_streaming="--nostream" not in sys.argv)
    print(report(st))
