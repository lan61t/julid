"""Daily box scores for the Yahoo Julid league (9 categories), embedded in the page state as state["box"].

Same engine as the Lapis box score (inseason_daily.build_daily with cats=9): every player line valued in FG% FT% 3PM PTS REB AST STL BLK TO,
luck, next-10 outlook from a 9-category model (data/research/daily_signal_model_9cat.json), usage, which rotation teammates sat out, and a
verdict. Owners come from the Yahoo snapshots (rosters.psv, free_agents.psv): "side" marks your players and this week's opponent's.
"""
import sys
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_daily as D  # noqa: E402
import inseason_live as L  # noqa: E402
import julid_engine as J  # noqa: E402

KEEP_MIN = 12          # lines under 12 minutes are only kept for your matchup's players (keeps the page small)


def owners_for(teams, opp_name, fa_path=None):
    """{"owner": {name key: {"team", "side"}}, "pct": {name key: % owned}, "inj": {name key: tag}} from the Yahoo snapshots."""
    owner, inj, pct = {}, {}, {}
    for t in teams.values():
        side = "me" if t["id"] == J.MY_TEAM else "opp" if t["name"] == opp_name else ""
        for p in t["roster"]:
            k = L.norm(p["name"])
            owner[k] = {"team": t["name"], "side": side}
            inj[k] = p["inj"]
    path = Path(fa_path or J.FA_FILE)
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            pid, name, info, own = (line.split("|") + ["", "", "", ""])[:4]
            k = L.norm(name)
            try:
                pct[k] = float(own.strip().strip("%") or 0)
            except ValueError:
                pass
            toks = info.split(" ", 1)
            if toks[0] in J.INJ_MAP and len(toks) > 1:
                inj[k] = J.INJ_MAP[toks[0]]
    return {"owner": owner, "pct": pct, "inj": inj}


def trim(day):
    day = dict(day)
    keep = []
    for p in day["players"]:
        if p["side"] or p["min"] >= KEEP_MIN:
            p = dict(p, z={c: round(v, 1) for c, v in p["z"].items()})
            for k in ("value", "neutral", "luck", "proj"):
                if p.get(k) is not None:
                    p[k] = round(p[k], 1)
            keep.append(p)
    day["players"] = keep
    return day


def build_box(state, teams, today, days=3, look_back=7):
    """state: the julid_engine state (for the opponent and the swing categories). Returns the dict stored as state["box"]."""
    import espn_site as ES
    cfg = D.get_cfg(9)
    need = [c["key"] for c in state.get("cats", []) if 0.2 < c.get("p", 0) < 0.65]
    own = owners_for(teams, state.get("opp"))
    out, dates = {}, []
    d = today
    for _ in range(look_back):
        if len(dates) >= days:
            break
        try:
            if any(g["done"] for g in ES.scoreboard(d)):
                res = D.build_daily(d, None, need, cats=9, owners=own)
                if res.get("players"):
                    out[d.isoformat()] = trim(res)
                    dates.append(d.isoformat())
        except Exception as e:
            print("julid box skipped", d, type(e).__name__, str(e)[:80])
        d -= timedelta(days=1)
    dates.sort()
    return {"dates": dates, "def": dates[-1] if dates else None, "cats": cfg["cats"], "labels": [cfg["label"][c] for c in cfg["cats"]], "days": out}
