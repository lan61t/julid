"""Turn a fresh Yahoo scrape (data/raw/yahoo.json, posted by julid/refresh/scrape.js) into the engine's input files and rebuild the page.

    python scripts/refresh_julid.py [--no-build] [--in yahoo.json]

Steps: validate the scrape (12 teams x 13 players, >=100 free agents, no scrape errors; otherwise nothing is overwritten) -> back up the old
files -> write rosters.psv, free_agents.psv, matchup_live.json -> print who was added/dropped/traded since last time -> rebuild
D:\\JH\\NBA\\julid\\site\\index.html. Prints "REFRESH OK ..." or "REFRESH FAILED ..." as the last line.
"""
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import os
RAW = Path(os.environ.get("JULID_RAW") or r"D:\JH\NBA\julid\data\raw")
SITE = Path(os.environ.get("JULID_SITE") or r"D:\JH\NBA\julid\site")
INFO = re.compile(r"^(?:(Q|D|O|NA|SUSP|INJ|IL|P|GTD|DTD)\s+)?([A-Z]{2,3})\s*-\s*(.+)$")
STAT_ORDER = ["fg", "fg%", "ft", "ft%", "3pm", "pts", "reb", "ast", "stl", "blk", "to"]


def parse_info(info):
    m = INFO.match(info.strip())
    if not m:
        raise ValueError(f"cannot parse player info {info!r}")
    return m.group(1) or "", m.group(2), m.group(3).replace(" ", "")


def num(x):
    try:
        return float(str(x).replace(",", ""))
    except ValueError:
        return 0.0


def made_att(s):
    m = re.match(r"^\s*([\d.,]+)\s*/\s*([\d.,]+)\s*$", str(s))
    return (num(m.group(1)), num(m.group(2))) if m else (0.0, 0.0)


def convert(j):
    """scrape json -> (rosters.psv text, free_agents.psv text, matchup_live dict, problems)"""
    problems = []
    if j.get("errors"):
        problems.append("scrape errors: " + "; ".join(j["errors"]))
    teams = j.get("teams", {})
    if len(teams) < 10:
        problems.append(f"only {len(teams)} teams scraped")
    lines = [f"# league 17676 Julid NBA League, {len(teams)} teams, scraped {j.get('ts')}. tid|team|yahoo_pid|name|slot|nba_team-positions|status"]
    for tid, t in sorted(teams.items(), key=lambda kv: int(kv[0])):
        if len(t["players"]) < 12:
            problems.append(f"team {tid} {t['name']} has only {len(t['players'])} players")
        for p in t["players"]:
            st, nba, pos = parse_info(p["info"])
            lines.append(f"{tid}|{t['name']}|{p['pid']}|{p['name']}|{p['slot']}|{nba}-{pos}|{st}")
    fa = ["# Yahoo league 17676 free agents by %% owned, scraped %s. pid|name|[status ]NBA-positions|%%owned" % j.get("ts")]
    for p in j.get("fa", []):
        try:
            st, nba, pos = parse_info(p["info"])
        except ValueError as e:
            problems.append(str(e))
            continue
        fa.append(f"{p['pid']}|{p['name']}|{(st + ' ') if st else ''}{nba} - {pos}|{p.get('own', '')}")
    if len(fa) - 1 < 100:
        problems.append(f"only {len(fa) - 1} free agents scraped")
    live = None
    m = j.get("matchup") or {}
    if m.get("week") and m.get("stats"):
        t = {}
        for name, cells in m["stats"].items():
            fgm, fga = made_att(cells[0])
            ftm, fta = made_att(cells[2])
            t[name] = {"fgm": fgm, "fga": fga, "ftm": ftm, "fta": fta, "3pm": num(cells[4]), "pts": num(cells[5]), "reb": num(cells[6]),
                       "ast": num(cells[7]), "stl": num(cells[8]), "blk": num(cells[9]), "to": num(cells[10])}
        live = {"week": m["week"], "teams": t, "ts": j.get("ts")}
    return "\n".join(lines) + "\n", "\n".join(fa) + "\n", live, problems


def roster_moves(old_text, new_text):
    """Who changed team since the last refresh, matched by Yahoo player id (names carry accents / quote variants)."""
    def parse(text):
        pl, tn = {}, {}
        for ln in text.splitlines():
            if ln.startswith("#") or not ln.strip():
                continue
            f = ln.split("|")
            pl[f[2]] = (f[0], f[3])
            tn[f[0]] = f[1]
        return pl, tn
    (o, _), (n, names) = parse(old_text), parse(new_text)
    out = []
    for pid in sorted(set(o) | set(n)):
        a, b = o.get(pid), n.get(pid)
        if a and b and a[0] == b[0]:
            continue
        who = (b or a)[1]
        out.append(f"{who}: {names.get(a[0], '?') if a else 'free agent'} -> {names.get(b[0], '?') if b else 'dropped to free agents'}")
    return out


def ranks_from(j):
    """Yahoo's own player ranks from the Players page: [{pid, name, pre, cur}] with integer ranks (Pre-Season = Yahoo's projection, Current =
    its live rank). Rows without a rank are dropped. Returns [] if the scrape has none (the old file is then kept)."""
    out = []
    for r in j.get("ranks") or []:
        try:
            pre, cur = int(str(r.get("pre", "")).replace(",", "")), int(str(r.get("cur", "")).replace(",", ""))
        except ValueError:
            continue
        out.append({"pid": str(r["pid"]), "name": r["name"], "pre": pre, "cur": cur})
    return out


def move_events(old_text, new_text, ts):
    """Structured roster moves between two rosters.psv texts, matched by Yahoo player id (a player's projection never matters here):
    one event per team with who came in and went out; a player who left one team and joined another in the same interval marks both as a TRADE."""
    def parse(text):
        pl, tn = {}, {}
        for ln in text.splitlines():
            if ln.startswith("#") or not ln.strip():
                continue
            f = ln.split("|")
            pl[f[2]] = (f[0], f[3])
            tn[f[0]] = f[1]
        return pl, tn
    (o, tn_o), (n, tn_n) = parse(old_text), parse(new_text)
    names = {**tn_o, **tn_n}
    ev = {}
    for pid in set(o) | set(n):
        a, b = o.get(pid), n.get(pid)
        if a and b and a[0] == b[0]:
            continue
        if b:
            e = ev.setdefault(b[0], {"in": [], "out": [], "partners": set()})
            e["in"].append(b[1])
            if a:
                e["partners"].add(a[0])
        if a:
            e = ev.setdefault(a[0], {"in": [], "out": [], "partners": set()})
            e["out"].append(a[1])
            if b:
                e["partners"].add(b[0])
    out = []
    for tid, e in sorted(ev.items(), key=lambda kv: int(kv[0])):
        out.append({"ts": ts, "team_id": int(tid), "team": names.get(tid, "?"), "kind": "TRADE" if e["partners"] else "MOVE",
                    "partner": ", ".join(sorted(names.get(x, "?") for x in e["partners"])) or None, "in": sorted(e["in"]), "out": sorted(e["out"])})
    return out


def main():
    src = Path(sys.argv[sys.argv.index("--in") + 1]) if "--in" in sys.argv else RAW / "yahoo.json"
    try:
        j = json.loads(src.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"REFRESH FAILED: cannot read {src}: {e}")
        return 1
    try:
        ros, fa, live, problems = convert(j)
    except Exception as e:
        print(f"REFRESH FAILED: cannot convert the scrape: {type(e).__name__}: {e}")
        return 1
    if problems:
        print("REFRESH FAILED: scrape rejected, nothing overwritten:\n  " + "\n  ".join(problems))
        return 1
    RAW.mkdir(parents=True, exist_ok=True)
    marker = RAW / "last_scrape_ts.txt"
    if "--if-new" in sys.argv and marker.exists() and marker.read_text().strip() == str(j.get("ts")):
        print("REFRESH OK (this scrape was already applied; nothing to do)")
        return 0
    old = (RAW / "rosters.psv").read_text(encoding="utf-8") if (RAW / "rosters.psv").exists() else ""
    if not os.environ.get("JULID_NO_HISTORY"):                       # local runs keep backups; the cloud repo is its own history
        hist = RAW / "history"
        hist.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M")
        for f in ("rosters.psv", "free_agents.psv", "matchup_live.json"):
            if (RAW / f).exists():
                shutil.copy2(RAW / f, hist / f"{stamp}_{f}")
        for old_f in sorted(hist.glob("*"))[:-60]:                  # keep the last 60 backups
            old_f.unlink()
    moves = roster_moves(old, ros) if old else []
    ts_now = str(j.get("ts"))
    if old:
        evs = move_events(old, ros, ts_now)
        if evs:
            try:
                log = json.loads((RAW / "moves_log.json").read_text(encoding="utf-8"))
            except Exception:
                log = []
            (RAW / "moves_log.json").write_text(json.dumps((evs + log)[:300]), encoding="utf-8")
    rk = ranks_from(j)
    if rk:
        (RAW / "ranks.json").write_text(json.dumps({"ts": j.get("ts"), "rows": rk}), encoding="utf-8")
    (RAW / "rosters.psv").write_text(ros, encoding="utf-8")
    (RAW / "free_agents.psv").write_text(fa, encoding="utf-8")
    if live:
        (RAW / "matchup_live.json").write_text(json.dumps(live), encoding="utf-8")
    marker.write_text(str(j.get("ts")), encoding="utf-8")
    print(f"scrape ok: {ros.count(chr(10)) - 1} rostered players, {fa.count(chr(10)) - 1} free agents, {len(rk)} ranked players, live totals {'yes' if live else 'no'}")
    print("roster moves since last refresh:" + ("\n  " + "\n  ".join(moves) if moves else " none"))
    if "--no-build" in sys.argv:
        print("REFRESH OK (files written, build skipped)")
        return 0
    import build_julid_site as B
    try:
        st = B.build(SITE)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"REFRESH FAILED: page build failed ({type(e).__name__}: {e}); input files were updated")
        return 1
    print(f"REFRESH OK: week {st['week']} vs {st['opp']}, P(win) {st['p_win']:.1%}, live totals {'used' if st.get('has_actual') else 'none yet'}, "
          f"{len(moves)} team(s) changed rosters; page at {SITE / 'index.html'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
