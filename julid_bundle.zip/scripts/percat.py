"""Per-category projections (13 categories) on the Rosenof 'Q-based' z scale, walk-forward validated.

Why: G-score / H-score need each player's category SHAPE for next season, not one summed number.
For every category c a separate regression predicts next season's z_c from that category's own history
(z_c over the last 3 seasons), age (curved), minutes, usage and the team/roster context that the scalar model
found useful (team change, prior team tier, vacated minutes, incoming/outgoing talent).

z scale: per-game stat standardised over Q = the 14 x 12 = 168 draftable players of that season (percentage
categories use volume-weighted impact: made - league_rate * attempts). TO and PF are sign-flipped so higher = better.

Run directly to print the walk-forward validation (per-category rank correlation vs naive, and total-value check).
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import projection_model as PM  # noqa: E402
import research_patterns as RP  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = RP.ROOT
CATS13 = ["pts", "stl", "blk", "oreb", "dreb", "fg_pct", "3pm", "3p_pct", "ftm", "ft_pct", "to", "pf", "ast"]
COUNT = {"pts": "PTS", "stl": "STL", "blk": "BLK", "oreb": "OREB", "dreb": "DREB", "3pm": "FG3M", "ftm": "FTM",
         "to": "TOV", "pf": "PF", "ast": "AST"}
PCT = {"fg_pct": ("FGM", "FGA"), "3p_pct": ("FG3M", "FG3A"), "ft_pct": ("FTM", "FTA")}
Q_SIZE = 14 * 12


def season_zq(df: pd.DataFrame) -> pd.DataFrame:
    """z on the Q scale for every player-season row of one season file."""
    pool = df[(df["GP"] >= 20) & (df["MIN"] >= 15)].copy()
    # first pass to pick Q: simple z-sum over the rotation pool
    z1 = pd.DataFrame(index=pool.index)
    for c, col in COUNT.items():
        z1[c] = (pool[col] - pool[col].mean()) / pool[col].std()
    for c, (a, b) in PCT.items():
        comp = pool[a].sum() / pool[b].sum()
        imp = pool[a] - comp * pool[b]
        z1[c] = (imp - imp.mean()) / imp.std()
    z1[["to", "pf"]] *= -1
    Q = pool.loc[z1.sum(axis=1).sort_values(ascending=False).head(Q_SIZE).index]
    z = pd.DataFrame(index=df.index)
    for c, col in COUNT.items():
        z[c] = (df[col] - Q[col].mean()) / Q[col].std()
    for c, (a, b) in PCT.items():
        comp = Q[a].sum() / Q[b].sum()
        imp_q = Q[a] - comp * Q[b]
        z[c] = ((df[a] - comp * df[b]) - imp_q.mean()) / imp_q.std()
    z[["to", "pf"]] *= -1
    return z[CATS13]


def build_panelQ():
    P, T = RP.load_all()
    zs = []
    for i, s in enumerate(RP.SEASONS):
        raw = pd.read_csv(RP.LONG / f"players_{s}.csv")
        z = season_zq(raw)
        z.columns = [f"zq_{c}" for c in z.columns]
        z["PLAYER_ID"] = raw["PLAYER_ID"].to_numpy()
        z["si"] = i
        zs.append(z)
    Zdf = pd.concat(zs, ignore_index=True)
    P = P.merge(Zdf, on=["PLAYER_ID", "si"], how="left")
    P["vq"] = P[[f"zq_{c}" for c in CATS13]].sum(axis=1)
    return P, T


def cat_pivots(P):
    return {c: P.pivot_table(index="PLAYER_ID", columns="si", values=f"zq_{c}") for c in CATS13}


def train_frame(P, RF, pivots, c):
    """Rows (player, target season t>=1) with features from seasons < t and target z_c(t)."""
    L = RP.link_prev(P.assign(value=P[f"zq_{c}"]))
    L = L.merge(RF, on=["TEAM_ID", "si"], how="left")
    pv, pg = pivots[c], P.pivot_table(index="PLAYER_ID", columns="si", values="gp_pct")
    F = L[(L["p_MIN"] >= 15) & (L["p_GP"] >= 30)].copy()
    for k in (1, 2, 3, 4):
        F[f"v{k}_raw"] = [pv.at[pid, si - k] if (si - k) in pv.columns and pid in pv.index else np.nan
                          for pid, si in zip(F["PLAYER_ID"], F["si"])]
        F[f"gp{k}_raw"] = [pg.at[pid, si - k] if (si - k) in pg.columns and pid in pg.index else np.nan
                           for pid, si in zip(F["PLAYER_ID"], F["si"])]
    X = PM.featurize(F)
    ok = X[PM.BASE + PM.CTX].notna().all(axis=1).to_numpy() & F["value"].notna().to_numpy()
    return F[ok], X[ok], F["value"].to_numpy()[ok]


def fit_all(P, RF, pivots, t_max=None):
    """Fit one model per category on rows with target season < t_max."""
    models, frames = {}, {}
    for c in CATS13:
        F, X, y = train_frame(P, RF, pivots, c)
        frames[c] = (F, X, y)
    return frames


def fit_models(frames, t):
    models = {}
    for c, (F, X, y) in frames.items():
        tr = F["si"].to_numpy() < t
        models[c] = PM.fit(X[tr], y[tr], PM.BASE + PM.CTX)
    return models


def cand_features(N, pivots, c, t):
    """N: candidate base frame (ids, age, min, usg, teams, tier, ctx, gp raws); adds cat-c z lags."""
    M = N.copy()
    for k in (1, 2, 3, 4):
        M[f"v{k}_raw"] = [pivots[c].at[pid, t - k] if (t - k) in pivots[c].columns and pid in pivots[c].index else np.nan
                          for pid in M["PLAYER_ID"]]
    X = PM.featurize(M)
    return X


def candidate_base(P, RF, pg, t):
    prev = P[(P["si"] == t - 1) & (P["MIN"] >= 12) & (P["GP"] >= 20)]
    cur = P[P["si"] == t].drop_duplicates("PLAYER_ID").set_index("PLAYER_ID")
    rf = RF[RF["si"] == t].set_index("TEAM_ID")
    rows = []
    for _, r in prev.iterrows():
        pid = r["PLAYER_ID"]
        team_t = cur.at[pid, "TEAM_ID"] if pid in cur.index else r["TEAM_ID"]
        f = rf.loc[team_t] if team_t in rf.index else None
        rows.append({"PLAYER_ID": pid, "PLAYER_NAME": r["PLAYER_NAME"], "p_AGE": r["AGE"], "p_MIN": r["MIN"],
                     "p_usg": r["usg"], "p_TEAM_ID": r["TEAM_ID"], "TEAM_ID": team_t, "p_tier": r["tier"], "si": t,
                     "vacated_share": f["vacated_share"] if f is not None else np.nan,
                     "in_talent": f["in_talent"] if f is not None else 0.0,
                     "out_talent": f["out_talent"] if f is not None else 0.0,
                     **{f"gp{k}_raw": (pg.at[pid, t - k] if (t - k) in pg.columns and pid in pg.index else np.nan) for k in (1, 2, 3, 4)}})
    return pd.DataFrame(rows)


def realized(P, N, t):
    cur = P[P["si"] == t].drop_duplicates("PLAYER_ID").set_index("PLAYER_ID")
    Z = np.zeros((len(N), len(CATS13))); gp = np.zeros(len(N)); mn = np.zeros(len(N))
    zc = [f"zq_{c}" for c in CATS13]
    for i, pid in enumerate(N["PLAYER_ID"]):
        if pid in cur.index:
            Z[i] = cur.loc[pid, zc].to_numpy(dtype=float)
            gp[i] = cur.at[pid, "gp_pct"]; mn[i] = cur.at[pid, "MIN"]
    return np.nan_to_num(Z), np.nan_to_num(gp), mn


def predict_cats(models, N, pivots, t, med_vac):
    Zp = np.zeros((len(N), len(CATS13)))
    ok = np.ones(len(N), dtype=bool)
    for j, c in enumerate(CATS13):
        X = cand_features(N, pivots, c, t)
        X["vacated_share"] = X["vacated_share"].fillna(med_vac)
        ok &= X[PM.BASE + PM.CTX].notna().all(axis=1).to_numpy()
        Zp[:, j] = PM.predict(models[c], X)
    return Zp, ok


def main():
    P, T = build_panelQ()
    RF = RP.roster_features(P)
    pivots = cat_pivots(P)
    pg = P.pivot_table(index="PLAYER_ID", columns="si", values="gp_pct")
    frames = fit_all(P, RF, pivots)
    med_vac = frames["pts"][0]["vacated_share"].median()
    rows = []
    for t in range(9, 21):
        models = fit_models(frames, t)
        N = candidate_base(P, RF, pg, t)
        Zr, gpr, mnr = realized(P, N, t)
        Zp, ok = predict_cats(models, N, pivots, t, med_vac)
        last = np.column_stack([cand_features(N, pivots, c, t)["v1"].to_numpy() for c in CATS13])
        sel = ok & (mnr > 0) & ~np.isnan(last).any(axis=1)
        for j, c in enumerate(CATS13):
            rows.append({"season": RP.SEASONS[t], "cat": c,
                         "rank_corr_model": pd.Series(Zp[sel, j]).rank().corr(pd.Series(Zr[sel, j]).rank()),
                         "rank_corr_last": pd.Series(last[sel, j]).rank().corr(pd.Series(Zr[sel, j]).rank()),
                         "mae_model": np.abs(Zp[sel, j] - Zr[sel, j]).mean(), "mae_last": np.abs(last[sel, j] - Zr[sel, j]).mean()})
    R = pd.DataFrame(rows)
    S = R.groupby("cat")[["rank_corr_model", "rank_corr_last", "mae_model", "mae_last"]].mean().loc[CATS13]
    S["gain_corr"] = S["rank_corr_model"] - S["rank_corr_last"]
    print("Walk-forward, 12 holdout seasons, per category (model vs 'same as last season'):")
    print(S.round(3).to_string())
    R.to_csv(RP.OUTD / "percat_backtest.csv", index=False)


if __name__ == "__main__":
    main()
